Maskit - by Dan Goodman
-----------------------

Usage instructions:

Run maskit.exe. Clicking the left mouse button on the slice
will set the lower left corner of the zoom box. The right
mouse button will set the upper right corner. Pressing Z
will zoom in to that box. As you zoom in, you will need to
increase the size of the maximum denominator. Press M to do
this. As a rough guide, you need to increase the maximum
denominator exponentially in the number of times you zoom
in.

By default, it will show you the pleating rays and the
"negative rays". The negative rays are the analytic
continuation of the pleating rays to the point where the
trace is zero (it is 2 at the cusp point). These can be
turned on and off on the Parameters / Rays menu. Here you
can also set the maximum denominator of rays.

The Newton menu is only relevant if you are doing very deep
zooms, and even then probably not. It just controls the
numerical precision of the computations.

The Special menu just does some computations related to my
PhD thesis.

You can save to various formats, but the two most useful
are Mathematica and Postscript. Studying the output of the
Mathematica save should be relatively self-explanatory.

Email me if you can't get it to work, would like to know
more, or if you want to try to get it to do something more
complicated.

dan@thesamovar.net