/*
 * Maskit Algorithms Implementation File
 *
 */

#include "common/common.hpp"
#include "maskit/maskitalgorithms.hpp"
#include "common/farey.hpp"
#include "common/gfxwrapper.hpp"
#include "common/progressbar.hpp"
#include "common/newton.hpp"
#include "common/commonmaths.hpp"
#include<sstream>
#include<list>
#include<stdlib.h>
#include<time.h>

#ifndef M_PI
#define M_PI 3.141592653589793238462643383279502884197169399375105820974944592307816
#endif

using namespace std;

using namespace maskit;

inline bool maskit::bbox::inside(const hg_complex& z) const
{
  if(z.real()>bl.real() && z.imag()>bl.imag() && z.real()<tr.real() && z.imag()<tr.imag()) return true;
  return false;
}

inline bool maskit::bbox::intersects(const hg_complex &start, const hg_complex &end) const
{
  // check if the segment is contained in any of the four regions entirely to the left, right,
  // top or bottom of the box
  if(start.real()<bl.real() && end.real()<bl.real()) return false;
  if(start.real()>tr.real() && end.real()>tr.real()) return false;
  if(start.imag()<bl.imag() && end.imag()<bl.imag()) return false;
  if(start.imag()>tr.imag() && end.imag()>tr.imag()) return false;
  // if one or both endpoints are inside then the segment intersects the box
  if(inside(start)||inside(end)) return true;
  // horizontal or vertical lines will (because the endpoints are in different regions)
  // necessarily intersect the box
  hg_real realdiff = -start.real() + end.real();
  if(is_zero(realdiff)) return true;
  hg_real imagdiff = -start.imag() + end.imag();
  if(is_zero(imagdiff)) return true;
  // check the intersection with the leftmost vertical line
  hg_real part, ratio = imagdiff / realdiff;;
  part = start.imag() + ratio * (bl.real()-start.real());
  if(part>bl.imag() && part<tr.imag()) return true;
  // check the intersection with the rightmost vertical line
  part = start.imag() + ratio * (tr.real()-start.real());
  if(part>bl.imag() && part<tr.imag()) return true;
  // now the lower line
  ratio = realdiff / imagdiff;
  part = start.imag() + ratio * (bl.imag()-start.imag());
  if(part>bl.real() && part<tr.real()) return true;
  // the upper line, this check can actually be skipped because a line must intersect
  // at least two of the sides

  // part = start.imag() + ratio * (tr.imag()-start.imag());
  // if(part>bl.real() && part<tr.real()) return true;

  // now, if none of these have returned true it must miss it
  return false;
}

inline hg_complex maskit::trace_eqn::operator() (hg_complex mu)
{
  ////////////////// Maskit Trace Polynomial //////////////////////
  // return trace_poly(f, -mu*imagunit, 2.0, -mu*imagunit - (hg_complex)2.0*imagunit ) - v;
  ////////////////// Earle Trace Polynomial ///////////////////////
  /*return trace_poly(f,
    ((hg_complex)2.0*mu*mu+(hg_complex)1.0)/mu,
    ((hg_complex)2.0*mu*mu+(hg_complex)1.0)/mu,
    (hg_complex)2.0*mu*mu+(hg_complex)2.0 ) - v;*/
  return trace_poly(f,
    hp->initial_trace_a(mu),
    hp->initial_trace_b(mu),
    hp->initial_trace_aB(mu))-v;
}

// this algorithm is straight out of Indra's Pearls
// it recursively computes Tr W_(p/q) given Tr a, Tr b and Tr aB
inline hg_complex maskit::trace_poly( farey &f, hg_complex tr_a, hg_complex tr_b, hg_complex tr_aB )
{
  if(f.p==0) return tr_a;
  else if(f.p==f.q) return tr_b;
  farey f1(0,1), f2(1,0), f3(1,1);
  hg_complex tr_u = tr_a, tr_v = tr_b, tr_uv = tr_aB, temp;
  while(f3!=f){
    if(f<f3){
      f2 = f3;
      f3 += f1;
      temp = tr_uv;
      tr_uv = tr_u * tr_uv - tr_v;
      tr_v = temp;
    } else{
      f1 = f3;
      f3 += f2;
      temp = tr_uv;
      tr_uv = tr_v * tr_uv - tr_u;
      tr_u = temp;
    }
  }
  return tr_uv;
}

bool view::create_postscript(const char* filename)
{
  postscript_gfx_wrapper pdisplay;
  gfx_wrapper &display = pdisplay;
  display.set_view_dimensions(params.viewport.left(),params.viewport.bottom(),params.viewport.right(),params.viewport.top());
  display.set_output_dimensions(7.0,11.0);
  display.set_output_filename(filename);
  if(!display.initialise()) return false;
  if(params.draw_nrays){
    for(bplist::iterator i=boundary.begin();i!=boundary.end();i++){
	    list<hg_complex> &nray = (*i).nray;
	    if(nray.size()>0){
	      display.colour((hg_real)((*i).f.p)/(hg_real)((*i).f.q),1.0,0.0);
	      display.moveto((*i).mu);
	      for(list<hg_complex>::iterator j=nray.begin();j!=nray.end();j++) display.lineto(*j);
	      display.stroke();
	    }
    }
  }
  if(params.draw_prays){
    for(bplist::iterator i=boundary.begin();i!=boundary.end();i++){
	    list<hg_complex> &ray = (*i).ray;
	    if(ray.size()>0){
	      display.colour(1.0,0.0,(hg_real)((*i).f.p)/(hg_real)((*i).f.q));
	      display.moveto((*i).mu);
	      for(list<hg_complex>::iterator j=ray.begin();j!=ray.end();j++) display.lineto(*j);
	      display.stroke();
	    }
    }
  }
  // draw boundary
  display.colour(0.0,0.0,0.0);
  display.moveto(boundary.front().mu);
  for(bplist::iterator i=boundary.begin();i!=boundary.end();i++) display.lineto((*i).mu);
  display.stroke();

  display.finished(true);
  return true;
}

bool view::create_ascii(const char* filename)
{
  ofstream fout(filename);
  if(!fout) return false;
  fout.precision(15); // this is about the maximum amount of precision you can squeeze out
                      // of a double precision variable
  fout << "Viewport (left bottom right top)\n" <<
    params.viewport.left() << "," <<
    params.viewport.bottom() << "," <<
    params.viewport.right() << "," <<
    params.viewport.top() << endl;
  fout << "Boundary (x y p q)\n";
  fout << boundary.size() << " points in total\n";
  bplist::iterator i;
  for(i=boundary.begin();i!=boundary.end();i++) {
    fout << (*i).mu.real() << " " << (*i).mu.imag() << " " << (*i).f.p << " " << (*i).f.q << endl;
  }
  if(params.draw_prays){
    fout << "pray - Positive Rays (x y) or (newray n p q) with n number of ray points\n";
    fout << numrays << " rays in total\n";
    for(i=boundary.begin();i!=boundary.end();i++){
	    list<hg_complex> &pray = (*i).ray;
	    if(pray.size()>0){
        fout << "newray " << pray.size()+1 << " " << (*i).f.p << " " << (*i).f.q << endl;
        fout << (*i).mu.real() << " " << (*i).mu.imag() << endl;
        for(list<hg_complex>::iterator j=pray.begin();j!=pray.end();j++) {
          fout << (*j).real() << " " << (*j).imag() << endl;
        }
	    }
    }
  }
  if(params.draw_nrays){
    fout << "nray - Negative Rays (x y) or (newray n p q) with n number of ray points\n";
    fout << numrays << " rays in total\n";
    for(i=boundary.begin();i!=boundary.end();i++){
	    list<hg_complex> &nray = (*i).nray;
	    if(nray.size()>0){
        fout << "newray " << nray.size() << " " << (*i).f.p << " " << (*i).f.q << endl;
        for(list<hg_complex>::iterator j=nray.begin();j!=nray.end();j++) {
          fout << (*j).real() << " " << (*j).imag() << endl;
        }
	    }
    }
  }
  fout << "end\n";
  fout.close();
  return true;
}

#define FOUTBINWRITE(var,type) { type temp = var; fout.write((const char*)&temp,sizeof(temp)); }
bool view::create_binary(const char* filename)
{
  ofstream fout(filename,ios::binary);
  if(!fout) return false;
  FOUTBINWRITE(params.viewport.left(),hg_real);
  FOUTBINWRITE(params.viewport.bottom(),hg_real);
  FOUTBINWRITE(params.viewport.right(),hg_real);
  FOUTBINWRITE(params.viewport.top(),hg_real);
  FOUTBINWRITE(boundary.size(),int);
  bplist::iterator i;
  for(i=boundary.begin();i!=boundary.end();i++) {
    FOUTBINWRITE((*i).mu.real(),hg_real);
    FOUTBINWRITE((*i).mu.imag(),hg_real);
    FOUTBINWRITE((*i).f.p,hg_int);
    FOUTBINWRITE((*i).f.q,hg_int);
  }
  if(params.draw_prays){
    FOUTBINWRITE(numrays,int);
    for(i=boundary.begin();i!=boundary.end();i++){
	    list<hg_complex> &pray = (*i).ray;
	    if(pray.size()>0){
        FOUTBINWRITE(pray.size()+1,int);
        FOUTBINWRITE((*i).f.p,hg_int);
        FOUTBINWRITE((*i).f.q,hg_int);
        FOUTBINWRITE((*i).mu.real(),hg_real);
        FOUTBINWRITE((*i).mu.imag(),hg_real);
        for(list<hg_complex>::iterator j=pray.begin();j!=pray.end();j++) {
          FOUTBINWRITE((*j).real(),hg_real);
          FOUTBINWRITE((*j).imag(),hg_real);
        }
	    }
    }
  }
  if(params.draw_prays){
    FOUTBINWRITE(numrays,int);
    for(i=boundary.begin();i!=boundary.end();i++){
	    list<hg_complex> &nray = (*i).nray;
	    if(nray.size()>0){
        FOUTBINWRITE(nray.size(),int);
        FOUTBINWRITE((*i).f.p,hg_int);
        FOUTBINWRITE((*i).f.q,hg_int);
        for(list<hg_complex>::iterator j=nray.begin();j!=nray.end();j++) {
          FOUTBINWRITE((*j).real(),hg_real);
          FOUTBINWRITE((*j).imag(),hg_real);
        }
	    }
    }
  }
  fout.close();
  return true;
}

// helper function: converts numbers of the form: AeB to A*10^B for Mathematica
string mathematica_number(hg_real x)
{
  char s[256],s2[256];
  // %g will print the number in AeB format, the .15 gives 15 digits of precision
  sprintf(s,"%.15g",x);
  char *t = strstr(s,"e");
  if(t)
  {
    t[0]=0;t++;
    strcpy(s2,s);
    strcat(s2,"*10^");
    strcat(s2,t);
  } else
  {
    strcpy(s2,s);
  }
  return string(s2);
}

string mathematica_number(hg_complex z)
{
	return mathematica_number(z.real())+"+I*"+mathematica_number(z.imag());
}

bool view::create_mathematica(const char* filename)
{
  ofstream fout(filename);
  if(!fout) return false;
  fout.precision(15); // this is about the maximum amount of precision you can squeeze out
                      // of a double precision variable
  fout << "maskitbdy = {" << endl;
  fout << "{" <<
    mathematica_number(params.viewport.left()) << "," <<
    mathematica_number(params.viewport.bottom()) << "," <<
    mathematica_number(params.viewport.right()) << "," <<
    mathematica_number(params.viewport.top()) << "}," << endl;

  fout << "{" << endl;
  bplist::iterator i;
  for(i=boundary.begin();i!=boundary.end();) {
    fout << "{" << 
      mathematica_number((*i).mu.real()) << "+I*" <<
      mathematica_number((*i).mu.imag()) << "," <<
      (*i).f.p << "/" <<
      (*i).f.q << "}";
    if(++i!=boundary.end()) fout << ",";
    fout << endl;
  }
  fout << "}";
  if(params.draw_prays){
    bool alreadyoutputtedonepray = false;
    fout << "," << endl << "{" << endl;
    for(i=boundary.begin();i!=boundary.end();i++){
	    list<hg_complex> &pray = (*i).ray;
	    if(pray.size()>0){
        if(alreadyoutputtedonepray) fout << "," << endl;
        fout << "{" << (*i).f.p << "/" << (*i).f.q << "," << endl << "{";
        fout << mathematica_number((*i).mu.real()) << "+I*" << mathematica_number((*i).mu.imag()) << ", ";
        for(list<hg_complex>::iterator j=pray.begin();j!=pray.end();) {
          fout << mathematica_number((*j).real()) << "+I*" << mathematica_number((*j).imag());
          if(++j!=pray.end()) fout << ", ";
        }
        fout << "}}";
        alreadyoutputtedonepray = true;
	    }
    }
    fout << endl << "}";
  }
  if(params.draw_nrays){
    bool alreadyoutputtedonenray = false;
    fout << "," << endl << "{" << endl;
    for(i=boundary.begin();i!=boundary.end();i++){
	    list<hg_complex> &nray = (*i).nray;
	    if(nray.size()>0){
        if(alreadyoutputtedonenray) fout << "," << endl;
        fout << "{" << (*i).f.p << "/" << (*i).f.q << "," << endl << "{";
        fout << mathematica_number((*i).mu.real()) << "+I*" << mathematica_number((*i).mu.imag()) << ", ";
        for(list<hg_complex>::iterator j=nray.begin();j!=nray.end();j) {
          fout << mathematica_number((*j).real()) << "+I*" << mathematica_number((*j).imag());
          if(++j!=nray.end()) fout << ", ";
        }
        fout << "}}";
        alreadyoutputtedonenray = true;
	    }
    }
    fout << endl << "}";
  }
  fout << endl << "};" << endl;
  return true;
}

/////////////////////////////////////////////////////////
//   Initialisation and others
/////////////////////////////////////////////////////////

view::view()
{
	break_fn = 0;
  hp = &global_maskit_holoparams;
}

void view::initial_computation()
{
  prev_params.clear();
  params.draw_prays = true;
  params.draw_nrays = true;
  //params.draw_prays = false;
  //params.draw_nrays = false;
  params.maxdenom = 80;
  params.maxdenomray = 10;
  params.boundary_level = (hg_real)0.;
  params.ray.max_accuracy = 0.1;
  params.ray.min_accuracy = 0.1;
  params.ray.initial_stepsize = 0.1;
  params.newton_params.epsilon = newton::def_epsilon;
  params.newton_params.maxiter = newton::def_maxiter;
  params.newton_params.parameter_accuracy = newton::def_parameter_accuracy;
  params.newton_params.value_accuracy = newton::def_value_accuracy;
  params.start = farey_0;
  params.end = farey_1;

  //  hp = &global_button_holoparams;
  hp = &global_maskit_holoparams;
  //  global_button_holoparams.w = hg_complex(2.0,0.0);
  //hp = &global_lambda_holoparams;
  //global_lambda_holoparams.lambda = 0.5;
  // hp = &global_earle_holoparams;

  params.initmu = hp->initial_mu();
  params.viewport.set(hg_complex(0.,1.),hg_complex(2.,3.));
//  params.viewport.set(hg_complex(-4.,-4.),hg_complex(4.,4.));

  run_params();
  prev_params.push_back(params);
}

void view::run_params()
{
  if(preview) preview->set_view_dimensions(params.viewport.left(),params.viewport.bottom(),params.viewport.right(),params.viewport.top());
  if(preview) preview->clear();
  compute_boundary(params.start,params.end,params.initmu);
  if(params.draw_prays) compute_prays();
  if(params.draw_nrays) compute_nrays();  
}

void view::recompute()
{
  run_params();
  if(prev_params.size()>=1) prev_params.pop_back();
  prev_params.push_back(params);
}

//////////////////////////////////////////////////////
//      Zoom
//////////////////////////////////////////////////////

// the algorithm below will not draw any boundary points
// outside the new viewport (unless the boundary curve
// leaves the viewport and then dips back in again)

void view::zoom(const bbox& Viewport)
{
  farey start, end;
  hg_complex initmu;
  // the first task is to find the first farey fraction inside the new
  // viewport
  bplist::iterator i,j;
  for(i=boundary.begin();i!=boundary.end();i++)
    if( Viewport.inside((*i).mu) ) break;
  // if there are no boundary points inside then we can't draw it
  if(i==boundary.end()){
    params.viewport = Viewport;
    if(preview) preview->clear();
    boundary.clear();
  }
  start = (*i).f;
  initmu = (*i).mu;
  for(j=i;j!=boundary.end();j++)
    if(Viewport.inside((*j).mu)) end = (*j).f;
  params.viewport = Viewport;
  params.start = start;
  params.end = end;
  params.initmu = initmu;
  run_params();
  prev_params.push_back(params);
}

void view::zoom_out()
{
  if(prev_params.size()<=1) return;
  prev_params.pop_back();
  view_parameters vp = prev_params.back();
  params = vp;
  run_params();
}

void view::zoom_to_boundary(hg_real aspectratio)
{
	bplist::iterator i;
	hg_real left,right,top,bottom;
	left = (*boundary.begin()).mu.real(); right=left;
	bottom = (*boundary.begin()).mu.imag(); top=bottom;
	for(i=boundary.begin();i!=boundary.end();i++)
	{
		hg_real x,y;
		x=(*i).mu.real();
		y=(*i).mu.imag();
		if(x<left) left=x;
		if(x>right) right=x;
		if(y<bottom) bottom=y;
		if(y>top) top=y;
	}
	hg_real ar = (right-left)/(top-bottom);
	if(ar<aspectratio)
	{
		hg_real mid = (right+left)/2.;
		hg_real w = (right-left)/2.;
		w *= aspectratio/ar;
		left = mid-w;
		right=mid+w;
	} else
	{
		hg_real mid = (bottom+top)/2.;
		hg_real w = (top-bottom)/2.;
		w *= ar/aspectratio;
		bottom = mid-w;
		top=mid+w;
	}
	bbox vp(hg_complex(left,bottom),hg_complex(right,top));
	params.viewport = vp;
}

//////////////////////////////////////////////////////
//      Boundary Computation using Newton
//////////////////////////////////////////////////////

#define POSSIBLE_BREAKPOINT if(break_fn) if(break_fn()) return;

void view::compute_boundary(farey& start, farey& end, hg_complex initmu)
{
  boundary.clear();
  hg_complex mu = initmu, oldmu = initmu;
  farey f1 = start, f2 = start, f3;
  boundary.push_back(boundary_point(f1,mu));
  if(progress){
    ostringstream oss;
    oss << "Computing boundary using the order " << params.maxdenom << " farey sequence";
    progress->set_message(oss.str());
    progress->set_max((int)(((hg_real)end-(hg_real)start)*((hg_real)params.maxdenom*(hg_real)params.maxdenom*3.0)/(M_PI*M_PI)));
    progress->set(0);
  }
  numrays = 0;
  if(preview) preview->colour(0.0,0.0,0.0);
  while(f2<end){
    f3 = f2;
    if(f2==f1) f3=next_in_sequence(f1,params.maxdenom);
    else f3 = next_in_sequence(f1,f2,params.maxdenom);
    f1 = f2;
    f2 = f3;
    if(f2==farey_1) break;
    //trace_eqn eq(f2,hp);
    trace_eqn eq(f2,(hg_real)2.*cosh((hg_real)f2.q*params.boundary_level/(hg_real)2.),hp);
    if(f2.q<=params.maxdenomray) numrays++;
    oldmu = mu;
    mu = newton::tsolve_analytic(eq,mu,params.newton_params);
    if(preview) preview->line(oldmu,mu);
    boundary.push_back(boundary_point(f2,mu));
    if(progress) (*progress)++;
	POSSIBLE_BREAKPOINT;
  }
  if(progress) progress->finished();
}

//////////////////////////////////////////////////////
//      Positive Ray Computation using Newton
//////////////////////////////////////////////////////

void view::compute_prays()
{
  hg_complex mu,oldmu;
  if(progress){
    ostringstream oss;
    oss << "Computing positive rays, order " << params.maxdenomray << " sequence consisting of " << numrays << " rays";
    progress->set_message(oss.str());
    progress->set_max(numrays);
    progress->set(0);
  }
  for(bplist::iterator i=boundary.begin();i!=boundary.end();i++){
    farey f = (*i).f;
    oldmu = mu = (*i).mu;
    list<hg_complex> &ray = (*i).ray;
    ray.clear();
    if(f.q<=params.maxdenomray && f!=farey_0 && f!=farey_1){
	    hg_real stepsize = params.ray.initial_stepsize;
	    for(hg_real v=2.0+stepsize;params.viewport.inside(mu);v+=stepsize){
	      trace_eqn eq(f,v,hp);
	      oldmu = mu;
          mu = newton::tsolve_analytic(eq,mu,params.newton_params);
	      if(preview){
	        preview->colour(1.0,0.0,(hg_real)f.p/(hg_real)f.q);
	        preview->line(oldmu,mu);
	      }
	      ray.push_back(mu);
          hg_real absdiff = abs(oldmu-mu);
	      if(absdiff<params.ray.max_accuracy) stepsize *= 2.0;
          if(absdiff>params.ray.min_accuracy) stepsize *= 0.5;
	    }
	    if(progress) (*progress)++;
    }
	POSSIBLE_BREAKPOINT
  }
  if(progress) progress->finished();
}

//////////////////////////////////////////////////////
//      Negative Ray Computation using Newton
//////////////////////////////////////////////////////

void view::compute_nrays()
{
  hg_complex mu,oldmu;
  if(progress){
    ostringstream oss;
    oss << "Computing negative rays, order " << params.maxdenomray << " sequence consisting of " << numrays << " rays";
    progress->set_message(oss.str());
    progress->set_max(numrays);
    progress->set(0);
  }
  for(bplist::iterator i=boundary.begin();i!=boundary.end();i++){
    farey f = (*i).f;
    oldmu = mu = (*i).mu;
    list<hg_complex> &ray = (*i).nray;
    ray.clear();
    if(f.q<=params.maxdenomray && f!=farey_0 && f!=farey_1){
      hg_real stepsize = params.ray.initial_stepsize;
      hg_real v;
      for(v=2.0-stepsize;params.viewport.inside(mu)&&v>=0.0;v-=stepsize){
	      trace_eqn eq(f,v,hp);
	      oldmu = mu;
        mu = newton::tsolve_analytic(eq,mu,params.newton_params);
	      if(preview){
	        preview->colour((hg_real)f.p/(hg_real)f.q,1.0,0.0);
	        preview->line(oldmu,mu);
	      }
	      ray.push_back(mu);
        hg_real absdiff = abs(oldmu-mu);
	      if(absdiff<params.ray.max_accuracy) stepsize *= 2.0;
        if(absdiff>params.ray.min_accuracy) stepsize *= 0.5;
	    }
      // now, we want it to end exactly at v=0.0 so:
      v = 0.0;
	    trace_eqn eq(f,v,hp);
	    oldmu = mu;
      mu = newton::tsolve_analytic(eq,mu,params.newton_params);
	    if(preview){
	      preview->colour((hg_real)f.p/(hg_real)f.q,1.0,0.0);
	      preview->line(oldmu,mu);
	    }
	    ray.push_back(mu);
	    if(progress) (*progress)++;
      POSSIBLE_BREAKPOINT
    }
  }
  if(progress) progress->finished();
}

//////////////////////////////////////////////////////
//      Cusp analysis
//////////////////////////////////////////////////////
/*
  Cusp analysis takes the current view, and for each
  cusp calculates a large number of Farey neighbours,
  outputting the data in Mathematica format (that is,
  a mathematica expression which can be read by simply
  typing <<"filename").

  The Mathematica data format is a list of lists, each
  sublist corresponding to one of the original cusps,
  and consisting simply of elements of the form
  { x, y, p, q }
  the first element of the sublist is the original cusp,
  which is repeated later on...
*/

void view::cusp_analysis(int n, int discard_n, char *filename)
{
  ofstream fout(filename);
  if(!fout) return;

  if(progress){
    ostringstream oss;
    oss << "Analysing " << boundary.size() << " cusps";
    progress->set_message(oss.str());
    progress->set_max(boundary.size());
    progress->set(0);
  }

  fout.precision(15);
  fout << "multicusps = {" << endl;

  bplist::iterator maincusp_i;
  for(maincusp_i=boundary.begin();maincusp_i!=boundary.end();maincusp_i++)
  {
    bplist localbdy;
    localbdy.push_back(*maincusp_i);
    int i;
    if(maincusp_i!=boundary.begin())
    {
      bplist::iterator maincusp_iprev = maincusp_i; maincusp_iprev--;
      // compute cusp points to the left of the original point
      farey fleft = (*maincusp_iprev).f;
      farey fright = (*maincusp_i).f;
      farey f = fleft;
      for(i=0;i<discard_n;i++) f+=fright;
      for(i=0;i<n;i++)
      {
        f+=fright;
        trace_eqn eq(f,hp);
        hg_complex mu = (*maincusp_i).mu;
        mu = newton::tsolve_analytic(eq,mu,params.newton_params);
        localbdy.push_back(boundary_point(f,mu));
        POSSIBLE_BREAKPOINT;
      }
    }
    localbdy.push_back(*maincusp_i);
    if(maincusp_i!=boundary.end())
    {
      bplist::iterator maincusp_inext = maincusp_i; maincusp_inext++;
      // compute cusp points to the right of the original point
      bplist localbdy2;
      farey fleft = (*maincusp_i).f;
      farey fright = (*maincusp_inext).f;
      farey f = fright;
      for(i=0;i<discard_n;i++) f+=fleft;
      for(i=0;i<n;i++)
      {
        f+=fleft;
        trace_eqn eq(f,hp);
        hg_complex mu = (*maincusp_i).mu;
        mu = newton::tsolve_analytic(eq,mu,params.newton_params);
        localbdy2.push_back(boundary_point(f,mu));
        POSSIBLE_BREAKPOINT;
      }
      // now localbdy2 has the points in backwards, so reverse it and add it to the localbdy
      localbdy2.reverse();
      localbdy.insert(localbdy.end(),localbdy2.begin(),localbdy2.end());
    }
    // now save this to the file...
    fout << "{" << endl;
    bplist::iterator j;
    for(j=localbdy.begin();j!=localbdy.end();j++)
    {
      fout << "{" << (*j).f.p << ", " << (*j).f.q << ", " << mathematica_number((*j).mu.real()) << "+I " << mathematica_number((*j).mu.imag()) << "}";
      bplist::iterator lbbi = localbdy.end(); lbbi--;
      if(j!=lbbi) fout << ",";
      fout << endl;
    }
    fout << "}";
    bplist::iterator bdybackiter = boundary.end(); bdybackiter--;
    if(maincusp_i!=bdybackiter) fout << ",";
    fout << endl;
    // increase progress bar
    if(progress) (*progress)++;
  }
  fout << "};" << endl;
  fout.close();
  if(progress) progress->finished();
}

//////////////////////////////////////////////////////
//      Trace Derivative analysis
//////////////////////////////////////////////////////
//
//  Compute trace derivatives at the cusp points for the
//  current view
//

hg_real view::tracederivative_analysis(const char *filename)
{
  ofstream fout(filename);
  if(!fout) return -1.0;

  fout.precision(15);
  fout << "tracederivatives = {" << endl;

  hg_real min_qsq_normalised_deriv = 10000.0;
  hg_real min_qlogq_normalised_deriv =10000.0;

  bplist::iterator i;
  for(i=boundary.begin();i!=boundary.end();i++)
  {
    trace_eqn eq((*i).f,0,hp);
    hg_real epsilon = params.newton_params.epsilon;
    hg_complex fndash,iepsilon=imagunit*epsilon;
    fndash = (eq((*i).mu+epsilon)-eq((*i).mu-epsilon))/epsilon;
    fndash += (eq((*i).mu+iepsilon)-eq((*i).mu-iepsilon))/iepsilon;
    fndash *= 0.25;
    //fout << "{" << (*i).f.p << "/" << (*i).f.q << "," << mathematica_number(abs(fndash)) << "}";
    fout << "{" << (*i).f.p << "/" << (*i).f.q << "," << mathematica_number(fndash.real()) <<"+I*" << mathematica_number(fndash.imag()) << "}";
    bplist::iterator bdybackiter = boundary.end(); bdybackiter--;
    if(i!=bdybackiter) fout << ",";
    fout << endl;
    hg_real absfndash = abs(fndash);
    absfndash /= (hg_real)(*i).f.q;
    absfndash /= (hg_real)(*i).f.q;
    if(absfndash<=min_qsq_normalised_deriv) min_qsq_normalised_deriv = absfndash;
    absfndash = abs(fndash);
    absfndash /= (hg_real)(*i).f.q;
    if((*i).f.q>=2) absfndash/=log((hg_real)(*i).f.q);
    if(absfndash<=min_qlogq_normalised_deriv) min_qlogq_normalised_deriv=absfndash;
  }
  fout << "};" << endl;
  fout.close();
  return min_qsq_normalised_deriv;
  //return min_qlogq_normalised_deriv;
}

//////////////////////////////////////////////////////
//      Trace Derivative analysis for small cf coeffs
//////////////////////////////////////////////////////
//
//  Computes the trace derivative for p/q->(1+sqrt(5))/2
//
//  Note: this really needs fixed it's sort of meaningless except for p=1, q=2
//  Really want to compute trace derivatives for CF's of the form [ 0 a_1 ... a_k 1 1 1 ... 1 ]
//  where a_1 to a_k are fixed and the number of 1's increases
//

bool view::tracederivative_analysis_smallcfcoeffs(char *filename, int n, int p, int q)
{
  ofstream fout(filename);
  if(!fout) return false;

  fout.precision(15);
  fout << "tracederivatives = {" << endl;

  // we start from p/q and continue from there, so make sure we know where that is exactly
  bool found_12=false;
  boundary_point bp, new_bp;
  bplist::iterator i;
  for(i=boundary.begin();i!=boundary.end();i++)
    if((*i).f.p==p && (*i).f.q==q)
    {
      found_12 = true;
      bp = *i;
      break;
    }
  if(!found_12) return false;

  int j;
  for(j=0;j<n;j++)
  {
    // new p/q is 1/(1+p/q)
    new_bp.f.p = bp.f.q;
    new_bp.f.q = bp.f.p + bp.f.q;
    // compute new cusp location
    trace_eqn eq(new_bp.f,(hg_complex)2.,hp);
    new_bp.mu = newton::tsolve_analytic(eq,bp.mu,params.newton_params);
    bp = new_bp;
    // compute derivative
    hg_real epsilon = params.newton_params.epsilon;
    hg_complex fndash,iepsilon=imagunit*epsilon;
    fndash = (eq(bp.mu+epsilon)-eq(bp.mu-epsilon))/epsilon;
    fndash += (eq(bp.mu+iepsilon)-eq(bp.mu-iepsilon))/iepsilon;
    fndash *= 0.25;
    // write to file
    fout << "{" << bp.f.p << "/" << bp.f.q << "," << mathematica_number(abs(fndash)) << "," << mathematica_number(real(eq(bp.mu))) << "+I*" << mathematica_number(imag(eq(bp.mu))) << "}";
    if(j!=n-1) fout << ",";
    fout << endl;
  }

  fout << "};" << endl;
  fout.close();

  return true;
}

//////////////////////////////////////////////////////
//      Boundary Compression analysis
//////////////////////////////////////////////////////
//
//  Numerical testing of the conjecture:
//
//  |f(x)-f(y)|/|x-y|->0 or infinity as y->x
//
//  For almost all x, where f(p/q) is the p/q-cusp
//
//  The method is to compute the cf convergents to
//  randomly chosen x
//

void view::boundarycompression_analysis(int n, int depth, char *filename)
{
  ofstream fout(filename);
  if(!fout) return;

  if(progress){
    ostringstream oss;
    oss << "Analysing " << n << " randomly chosen points";
    progress->set_message(oss.str());
    progress->set_max(n);
    progress->set(0);
  }

  srand((unsigned int)time(NULL));

  int num_discarded = 0;
  int i,j;

  fout << "bdycomp = {" << endl;

  for(i=0;i<n;i++)
  {
    hg_real x = (hg_real)rand()/(hg_real)RAND_MAX;
    hg_real xorig=x;
    vector<hg_int> cfcoeff;
    list<farey> convergents;
    cfcoeff.resize(depth);
    bool trouble_free = true;
    // calculate continued fraction coefficients by standard algorithm
    // if we get overflow errors set trouble_free to be false
    for(j=0;j<depth;j++)
    {
      x=1./x;
      cfcoeff[j]=(hg_int)x;
      x-=cfcoeff[j];
      if(cfcoeff[j]<=0) { trouble_free=false; i--; num_discarded++; break; }
    }
    // compute the convergents, as above for overflow errors
    if(trouble_free)
    {
      int d;
      for(d=1;d<=depth;d++)
      {
        hg_int p = 1, q = cfcoeff[d-1], np, nq;
        for(j=d-2;j>=0;j--)
        {
          np = q;
          nq = cfcoeff[j]*q+p;
          if(nq<0) { trouble_free=false; i--; num_discarded++; break; }
          p=np;
          q=nq;
        }
        if(!trouble_free) break;
        convergents.push_back(farey(p,q));
      }
    }
    if(!trouble_free) continue;
    // find the closest farey fraction already computed for the first convergent
    bplist::iterator bpi;
    farey f = *(convergents.begin());
    hg_complex initmu;
    hg_real diff = 1000.0;
    bool exact_match = false;
    for(bpi=boundary.begin();bpi!=boundary.end();bpi++)
    {
      if((*bpi).f==f)
      {
        initmu=(*bpi).mu;
        diff=0.0;
        exact_match = true;
        break;
      }
      hg_real d = (hg_real)f-(hg_real)((*bpi).f);
      if(d<diff)
      {
        diff = d;
        initmu = (*bpi).mu;
      }
    }
    hg_complex mu = initmu;
    if(!exact_match)
    {
      trace_eqn eq(f,hp);
      mu = newton::tsolve_analytic(eq,mu,params.newton_params);
    }
    // compute all the convergents
    bplist convmu;
    convmu.push_back(boundary_point(f,mu));
    list<farey>::iterator lfi;
    for(lfi=convergents.begin(),lfi++;lfi!=convergents.end();lfi++)
    {
      f=*lfi;
      trace_eqn eq(f,hp);
      mu = newton::tsolve_analytic(eq,mu,params.newton_params);
      convmu.push_back(boundary_point(f,mu));
      POSSIBLE_BREAKPOINT;
    }
    convmu.pop_back();
    fout << "{";
    for(bpi=convmu.begin();bpi!=convmu.end();bpi++)
    {
      if(bpi!=convmu.begin()) fout << ",";
      fout << mathematica_number(abs((*bpi).mu-mu)/fabs((hg_real)((*bpi).f)-xorig));
    }
    fout << "}";
    if(i<n-1) fout << ",";
    fout << endl;
    if(progress) (*progress)++;
  }
  fout << "};" << endl;
  fout << "numdiscarded = " << num_discarded << ";" << endl;

  fout.close();
  if(progress) progress->finished();
}


//////////////////////////////////////////////////////
//           Image Circle Analysis
//////////////////////////////////////////////////////
// 
//  For every p/q we draw a circle around mu_p/q of
//  radius eps/Tr'_p/q, find the image under the
//  trace function. We hope that this image will be
//  contained in an annulus around 2 of universal
//  inner and outer radius.
//
//

pair<hg_real,hg_real> view::imagecircleanalysis(hg_real eps, int steps, const char *filename)
{
  pair<hg_real,hg_real> rval(1000.,0.);
  ofstream fout;
  if(strlen(filename)>0)
  {
	fout.open(filename);
	if(!fout) return rval;

	fout.precision(15);
	fout << "imagecircles = {" << endl;
  }

  bplist::iterator i;
  for(i=boundary.begin();i!=boundary.end();i++)
  {
    trace_eqn eq((*i).f,0,hp);
    hg_real epsilon = params.newton_params.epsilon;
    hg_complex fndash,iepsilon=imagunit*epsilon;
    fndash = (eq((*i).mu+epsilon)-eq((*i).mu-epsilon))/epsilon;
    fndash += (eq((*i).mu+iepsilon)-eq((*i).mu-iepsilon))/iepsilon;
    fndash *= 0.25;
    if(filename) fout << "{" << (*i).f.p << "/" << (*i).f.q << ", {" << endl;
    hg_real rad = eps/abs(fndash);
	for(int j=0;j<steps;j++)
	{
		hg_complex mu(cos(2.*M_PI*(hg_real)j/(hg_real)steps),sin(2.*M_PI*(hg_real)j/(hg_real)steps));
		mu *= rad;
		mu += (*i).mu;
		hg_complex fmu = eq(mu);
		if(filename)
		{
			fout << mathematica_number(fmu);
			if(j<steps-1) fout << ",";
			fout << endl;
		}
		fmu = fmu-(hg_complex)2.;
		hg_real a = abs(fmu);
		if(a<rval.first) rval.first = a;
		if(a>rval.second) rval.second = a;
	}
	if(filename)
	{
		fout << "}}";
		bplist::iterator bdybackiter = boundary.end(); bdybackiter--;
		if(i!=bdybackiter) fout << ",";
		fout << endl;
	}
  }
  if(filename)
  {
	fout << "};" << endl;
	fout.close();
  }
  return rval;
}