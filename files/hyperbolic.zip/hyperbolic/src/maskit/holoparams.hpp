/*

  Holomorphic Parameters
  Header

  */

#ifndef HG_HOLOPARAMS_H
#define HG_HOLOPARAMS_H

#include "common/common.hpp"
#include "common/commonmaths.hpp"

class holoparams
{
public:
  virtual hg_complex initial_trace_a(hg_complex mu) = 0;
  virtual hg_complex initial_trace_b(hg_complex mu) = 0;
  virtual hg_complex initial_trace_aB(hg_complex mu) = 0;
  virtual hg_complex initial_mu() = 0;
};

class maskit_holoparams : public holoparams
{
public:
  virtual hg_complex initial_trace_a(hg_complex mu);
  virtual hg_complex initial_trace_b(hg_complex mu);
  virtual hg_complex initial_trace_aB(hg_complex mu);
  virtual hg_complex initial_mu();
};

class earle_holoparams : public holoparams
{
public:
  virtual hg_complex initial_trace_a(hg_complex mu);
  virtual hg_complex initial_trace_b(hg_complex mu);
  virtual hg_complex initial_trace_aB(hg_complex mu);
  virtual hg_complex initial_mu();
};

class lambda_holoparams : public holoparams
{
public:
  hg_complex lambda;
  virtual hg_complex initial_trace_a(hg_complex mu);
  virtual hg_complex initial_trace_b(hg_complex mu);
  virtual hg_complex initial_trace_aB(hg_complex mu);
  virtual hg_complex initial_mu();
};

class button_holoparams : public holoparams
{
public:
  hg_complex w;
  virtual hg_complex initial_trace_a(hg_complex mu);
  virtual hg_complex initial_trace_b(hg_complex mu);
  virtual hg_complex initial_trace_aB(hg_complex mu);
  virtual hg_complex initial_mu();
};

extern maskit_holoparams global_maskit_holoparams;
extern earle_holoparams global_earle_holoparams;
extern lambda_holoparams global_lambda_holoparams;
extern button_holoparams global_button_holoparams;

#endif
