/*

  Holomorphic Parameters
  Implementation

*/

#include "maskit/holoparams.hpp"
#include<complex>

using namespace std;

maskit_holoparams global_maskit_holoparams;
earle_holoparams global_earle_holoparams;
lambda_holoparams global_lambda_holoparams;
button_holoparams global_button_holoparams;

/////////// MASKIT /////////////////

hg_complex maskit_holoparams::initial_mu()
{
  return hg_complex(0,2);
}

hg_complex maskit_holoparams::initial_trace_a(hg_complex mu)
{
  return -mu*imagunit;
}

hg_complex maskit_holoparams::initial_trace_b(hg_complex mu)
{
  return 2.0;
}

hg_complex maskit_holoparams::initial_trace_aB(hg_complex mu)
{
  // TODO: this should be -2mu+2I, change this and change the
  // x-range from [-2,0] to [0,2]
  return -mu*imagunit + (hg_complex)2.0*imagunit;
}

////////// EARLE //////////////////

hg_complex earle_holoparams::initial_mu()
{
  return hg_complex(0.5,0.5);
}

hg_complex earle_holoparams::initial_trace_a(hg_complex mu)
{
  return ((hg_complex)2.0*mu*mu+(hg_complex)1.0)/mu;
}

hg_complex earle_holoparams::initial_trace_b(hg_complex mu)
{
  return ((hg_complex)2.0*mu*mu+(hg_complex)1.0)/mu;
}

hg_complex earle_holoparams::initial_trace_aB(hg_complex mu)
{
  return (hg_complex)2.0*mu*mu+(hg_complex)2.0;
}

////////// LAMBDA /////////////////

hg_complex lambda_holoparams::initial_mu()
{
  if(is_zero(lambda)) return hg_complex(0,2);
  return (hg_complex)2.0*imagunit*asin(tanh(lambda))/lambda;
}

hg_complex lambda_holoparams::initial_trace_a(hg_complex mu)
{
  if(is_zero(lambda)) return -imagunit*mu;
  return -imagunit*sinh(lambda*mu*(hg_complex)0.5)/tanh(lambda*(hg_complex)0.5)
    -imagunit*sinh(lambda*mu*(hg_complex)0.5)*tanh(lambda*(hg_complex)0.5);
}

hg_complex lambda_holoparams::initial_trace_b(hg_complex mu)
{
  return (hg_complex)2.0*cosh(lambda);
}

hg_complex lambda_holoparams::initial_trace_aB(hg_complex mu)
{
  if(is_zero(lambda)) return -imagunit*((hg_complex)(-2.0)+mu);
  return imagunit*cosh(lambda)*sinh(lambda-lambda*mu*(hg_complex)0.5)/(cosh(lambda*(hg_complex)0.5)*sinh(lambda*(hg_complex)0.5));
}

////////// BUTTON /////////////////

hg_complex button_holoparams::initial_mu()
{
  return (hg_complex)1.0+imagunit*w;
}

hg_complex button_holoparams::initial_trace_a(hg_complex mu)
{
  return ((hg_complex)1.0+w*w)/mu+mu;
}

hg_complex button_holoparams::initial_trace_b(hg_complex mu)
{
  return ((hg_complex)1.0+mu*mu)/w+w;
}

hg_complex button_holoparams::initial_trace_aB(hg_complex mu)
{
  return (w/mu)*((hg_complex)1.0+w*w)+(mu/w)*((hg_complex)1.0+mu*mu);
}
