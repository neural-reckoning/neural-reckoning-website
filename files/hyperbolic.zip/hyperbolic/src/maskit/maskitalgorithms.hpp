/*
 * Maskit Algorithms Header File
 *
 */

#ifndef HG_MASKIT_ALGORITHMS_H
#define HG_MASKIT_ALGORITHMS_H

#include "common/common.hpp"
#include<vector>
#include<list>
#include<utility>
#include "common/commonmaths.hpp"
#include "common/farey.hpp"
#include "common/gfxwrapper.hpp"
#include "common/progressbar.hpp"
#include "common/newton.hpp"
#include "maskit/holoparams.hpp"

namespace maskit
{

  using std::list;
  using std::vector;
  using std::pair;

  class bbox
  {
    hg_complex bl, tr; // bottom left and top right
  public:
    bbox() : bl(0), tr(1,1) {}
    bbox(hg_complex BL, hg_complex TR) : bl(BL), tr(TR) {}
    void set(hg_complex BL, hg_complex TR) { bl = BL; tr = TR; }
    inline hg_real left() const { return bl.real(); }
    inline hg_real right() const { return tr.real(); }
    inline hg_real top() const { return tr.imag(); }
    inline hg_real bottom() const { return bl.imag(); }
    inline hg_complex bottom_left() const { return bl; }
    inline hg_complex top_right() const { return tr; }
    inline bool intersects(const hg_complex &start, const hg_complex& end) const; // returns true if the line segment intersects the box
    inline bool inside(const hg_complex &z) const; // returns true if z is in the box
  };

  // this class is a bit of technical stuff, since we want to compute
  // the real trace rays we need to know (for each point on the boundary)
  // the farey fraction for that point. Since we also need to keep a copy
  // of the list of ray points these are thrown in as well. There is one
  // boundary_point object for each point computed by the first pass of
  // the algorithm (boundary trace).
  class boundary_point
  {
  public:
    farey f;
    hg_complex mu;
    list<hg_complex> ray;
    list<hg_complex> nray; // negative ray
    boundary_point() : f(0,1), mu(0) { ray.clear(); nray.clear(); }
    boundary_point(farey &F, hg_complex Mu) : f(F), mu(Mu) { ray.clear(); nray.clear(); }
    void set(farey &F, hg_complex Mu) { f=F; mu=Mu; ray.clear(); nray.clear(); }
  };

  typedef std::list<boundary_point> bplist; // just a shorthand

  struct ray_parameters
  {
    hg_real max_accuracy;
    hg_real min_accuracy;
    hg_real initial_stepsize;
  };

  struct view_parameters
  {
    farey start, end;
    hg_complex initmu;
    bbox viewport;
    int maxdenom, maxdenomray;
    hg_real boundary_level;
    newton::params newton_params;
    ray_parameters ray;
    bool draw_prays, draw_nrays;
  };

  class view
  {
    bplist boundary; // visible boundary segment
    gfx_wrapper* preview;
    progress_bar* progress;
    int numrays;
    holoparams* hp;
    view_parameters params;
    list<view_parameters> prev_params;
	  bool (*break_fn)(void);
  public:
	  view();
    view_parameters& get_params() { return params; }
  	void set_break_fn(bool (*Break_Fn)(void)) { break_fn = Break_Fn; }
    void set_maxdenom(int MaxDenom) { params.maxdenom = MaxDenom; }
    void set_maxdenomray(int MaxDenomRay) { params.maxdenomray = MaxDenomRay; }
    void set_newton_params(newton::params& Newton_Params) { params.newton_params = Newton_Params; }
    void set_ray_params(hg_real max, hg_real min, hg_real init_step) { params.ray.max_accuracy = max; params.ray.min_accuracy = min; params.ray.initial_stepsize = init_step; }
	void set_boundary_level(hg_real level) { params.boundary_level = level; }
    void show_prays(bool truthval) { params.draw_prays = truthval; }
    void show_nrays(bool truthval) { params.draw_nrays = truthval; }
    void set_preview(gfx_wrapper* Preview) { preview = Preview; }
    void set_progress_bar(progress_bar* Progress) { progress = Progress; }
    void initial_computation(); // compute the initial view
    void run_params();
    void compute_boundary(farey& start, farey& end, hg_complex initmu);
    void compute_prays();
    void compute_nrays();
    void recompute();
    void zoom(const bbox& Viewport);
    void zoom_out();
	void zoom_to_boundary(hg_real aspectratio);
	void zoom_to_boundary() { zoom_to_boundary(1.41421); } // sqrt(2) is the aspect ratio for An serie of paper
    void boundarycompression_analysis(int n, int depth, char *filename);
    void cusp_analysis(int n, int discard_n, char *filename);
    hg_real tracederivative_analysis(const char *filename);
    bool tracederivative_analysis_smallcfcoeffs(char *filename, int n, int p, int q);
	pair<hg_real,hg_real> imagecircleanalysis(hg_real eps, int steps, const char *filename);
    bool create_postscript(const char* filename);
    bool create_ascii(const char* filename);
    bool create_binary(const char* filename);
    bool create_mathematica(const char* filename);
  };

  // this class is a function object depending on two parameters used
  // as the input to the newton solver later on : the two parameters
  // are the farey fraction under consideration and the value v
  // where we want to solve poly(mu)=v.
  class trace_eqn
  {
  public:
    holoparams *hp;
    farey f;
    hg_complex v;
    trace_eqn(farey &F) : f(F), v(2), hp(&global_maskit_holoparams) {}
    trace_eqn(farey &F, hg_complex V) : f(F), v(V), hp(&global_maskit_holoparams) {}
    trace_eqn(farey &F, holoparams *HP) : f(F), v(2), hp(HP) {}
    trace_eqn(farey &F, hg_complex V, holoparams *HP) : f(F), v(V), hp(HP) {}
    inline hg_complex operator() (hg_complex mu);
  };

  // this algorithm is straight out of Indra's Pearls
  // it recursively computes Tr W_(p/q) given Tr a, Tr b and Tr aB
  inline hg_complex trace_poly( farey &f, hg_complex tr_a, hg_complex tr_b, hg_complex tr_aB );

} // namespace maskit

#endif