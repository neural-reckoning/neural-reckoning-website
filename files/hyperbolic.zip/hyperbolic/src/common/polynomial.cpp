/*

Polynomial Implementation

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

#include "common/polynomial.hpp"
#include "common/commonmaths.hpp"
#include<vector>

using namespace std;

const int max_polynomial_temp = 128;

polynomial& get_polynomial_temp()
{
  static int nbuf = 0;
  static polynomial buf[max_polynomial_temp];
  if(nbuf==max_polynomial_temp) nbuf = 0;
  return buf[nbuf++];
}

polynomial& operator+ (const polynomial& p1, const polynomial& p2)
{
  polynomial& temp = get_polynomial_temp();
  add(temp,p1,p2);
  return temp;
}

polynomial& operator- (const polynomial& p1, const polynomial& p2)
{
  polynomial& temp = get_polynomial_temp();
  sub(temp,p1,p2);
  return temp;
}

polynomial& operator* (const polynomial& p1, const polynomial& p2)
{
  polynomial& temp = get_polynomial_temp();
  mul(temp,p1,p2);
  return temp;
}

polynomial& operator* (const polynomial& p1, hg_complex a)
{
  polynomial& temp = get_polynomial_temp();
  mul(temp,p1,a);
  return temp;
}

polynomial& operator* (hg_complex a, const polynomial& p1)
{
  polynomial& temp = get_polynomial_temp();
  mul(temp,p1,a);
  return temp;
}

polynomial& polynomial::operator+=( const polynomial& p)
{
  return add(*this,p);
}

polynomial& polynomial::operator-=( const polynomial& p)
{
  return sub(*this,p);
}

polynomial& polynomial::operator*=( hg_complex a )
{
  return mul(*this,a);
}

hg_complex polynomial::operator() (hg_complex z) const
{
  hg_complex temp = 0.0, ztemp = 1.0;
  for(int i=0;i<coeff.size();i++){
    temp += coeff[i]*ztemp;
    ztemp *= z;
  }
  return temp;
}

ostream& operator<< (ostream& os, const polynomial& p)
{
  if(p.degree()==-1) return os << "0";
  bool is_first = true;
  for(int i=0;i<p.size();i++){
    hg_complex c = p.coefficient(i);
    if(!is_zero(c)){
      if(!is_first){
        os << " + ";
      } else {
        is_first = false;
      }
      os << c << "z^" << i;
    }
  }
  return os;
}

polynomial& add(polynomial& result, const polynomial& p)
{
  if(result.size()<p.size()) result.resize(p.size());
  for(int i=0;i<p.size();i++) result[i]+=p.coefficient(i);
  return result;
}

polynomial& add(polynomial& result, const polynomial& p1, const polynomial& p2)
{
  result = p1;
  return add(result,p2);
}

polynomial& sub(polynomial& result, const polynomial& p)
{
  if(result.size()<p.size()) result.resize(p.size());
  for(int i=0;i<p.size();i++) result[i]-=p.coefficient(i);
  return result;
}

polynomial& sub(polynomial& result, const polynomial& p1, const polynomial& p2)
{
  result = p1;
  return sub(result,p2);
}

polynomial& mul(polynomial& result, const polynomial& p1, const polynomial& p2)
{
  result.resize(p1.size()+p2.size()-1);
  for(int i=0;i<result.size();i++){
    result[i]=0;
    for(int j=0;j<=i;j++){
      if(j<p1.size() && (i-j)<p2.size()) result[i] += p1.coefficient(j) * p2.coefficient(i-j);
    }
  }
  return result;
}

polynomial& mul(polynomial& result, hg_complex a)
{
  for(int i=0;i<result.size();i++) result[i]*=a;
  return result;
}

polynomial& mul(polynomial& result, const polynomial& p, hg_complex a)
{
  result = p;
  return mul(result,a);
}

polynomial& mul(polynomial& result, hg_complex a, const polynomial& p)
{
  result = p;
  return mul(result,a);
}

// returns -1 if the poly is zero, rather than -infinity
int polynomial::degree() const
{
  int deg = -1;
  for(int i=0;i<coeff.size();i++){
    if(!is_zero(coeff[i])) deg=i;
  }
  return deg;
}

int degree(const polynomial &p)
{
  return p.degree();
}
