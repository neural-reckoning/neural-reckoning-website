/*

Polynomial Header

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman



Some arithmetic operators are provided, but beware the coefficients
remain on the static buffer so if you are messing around with large polynomials
you may easily have 128 large polynomials sitting on the buffer, not a good
idea. If you can, better to use the += operators or the add, mul, sub functions
defined.

The size, resize, reserve functions key straight into the vector of coefficients

A variable length constructor is provided, the first coefficient is the 0th one
and they increase from there

degree() returns the highest nonzero coefficient or -1 if there is none

 */

#ifndef HG_POLYNOMIAL_H
#define HG_POLYNOMIAL_H

#include "common/commonmaths.hpp"
#include<vector>
#include<iostream>

class polynomial
{
 public:
  // data
  std::vector<hg_complex> coeff;                    // arbitary number of coeffs
  // operators

  // these operators would be terribly memory inefficient to use on large
  // polynomials, better to use the uglier C style functions below
  friend polynomial& operator+ (const polynomial& p1, const polynomial& p2);
  friend polynomial& operator- (const polynomial& p1, const polynomial& p2);
  friend polynomial& operator* (const polynomial& p1, const polynomial& p2);
  friend polynomial& operator* (const polynomial& p, hg_complex a);
  friend polynomial& operator* (hg_complex a, const polynomial& p);

  polynomial& operator+= (const polynomial& p);
  polynomial& operator-= (const polynomial& p);
  polynomial& operator*= (hg_complex a);

  hg_complex operator() (hg_complex z) const;             // returns p(z)
  hg_complex& operator[] (int n) { return coeff[n]; }

  friend std::ostream& operator<< (std::ostream& os, const polynomial& p);

  // functions

  polynomial() {}
  polynomial(hg_complex coeff0 ...);           // initialise with a list of coeffs

  friend polynomial& add(polynomial& result, const polynomial& p1, const polynomial& p2);
  friend polynomial& add(polynomial& result, const polynomial& p);
  friend polynomial& sub(polynomial& result, const polynomial& p1, const polynomial& p2);
  friend polynomial& sub(polynomial& result, const polynomial& p);
  friend polynomial& mul(polynomial& result, const polynomial& p1, const polynomial& p2);
  friend polynomial& mul(polynomial& result, const polynomial& p1, hg_complex a);
  friend polynomial& mul(polynomial& result, hg_complex a, const polynomial& p1);
  friend polynomial& mul(polynomial& result, hg_complex a);

  int degree() const;                      // highest nonzero coeff
  int size() const { return coeff.size(); }
  void reserve(int n) { coeff.reserve(n); }
  void resize(int n) { coeff.resize(n); }
  hg_complex coefficient(int n) const { return coeff[n]; }
  friend int degree(const polynomial &p);
};

#endif
