/*

Extended hg_complexs Implementation

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

#include "common/extcomplex.hpp"
#include "common/commonmaths.hpp"
#include<iostream>

using namespace std;

const int max_ext_hg_complex_temp = 128;

ext_hg_complex& get_ext_hg_complex_temp()
{
  static int nbuf = 0;
  static ext_hg_complex buf[max_ext_hg_complex_temp];
  if(nbuf==max_ext_hg_complex_temp) nbuf = 0;
  return buf[nbuf++];
}

ext_hg_complex& operator+(const ext_hg_complex& lhs, hg_complex rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp = lhs;
  temp.p += rhs * temp.q;
  return temp;
}

ext_hg_complex& operator+(hg_complex lhs, const ext_hg_complex& rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp = rhs;
  temp.p += lhs * temp.q;
  return temp;
}

ext_hg_complex& operator-(const ext_hg_complex& lhs, hg_complex rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp = lhs;
  temp.p -= rhs * temp.q;
  return temp;
}

ext_hg_complex& operator-(hg_complex lhs, const ext_hg_complex& rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp = rhs;
  temp.p -= lhs * temp.q;
  return temp;
}

// warning: might return an invalid ext_hg_complex, e.g. (1,0)*0=(0,0)
ext_hg_complex& operator*(const ext_hg_complex& lhs, hg_complex rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp = lhs;
  temp.p *= rhs;
  return temp;
}

// warning: might return an invalid ext_hg_complex, e.g. 0*(1,0)=(0,0)
ext_hg_complex& operator*(hg_complex lhs, const ext_hg_complex& rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp = rhs;
  temp.p *= lhs;
  return temp;
}

// warning: might return an invalid ext_hg_complex, e.g. (0,1)*(1,0)=(0,0)
ext_hg_complex& operator*(const ext_hg_complex& lhs, const ext_hg_complex& rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp = lhs;
  temp.p *= rhs.p;
  temp.q *= rhs.q;
  return temp;
}

// warning: might return an invalid ext_hg_complex, e.g. (0,1)/0=(0,0)
ext_hg_complex& operator/(const ext_hg_complex& lhs, hg_complex rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp = lhs;
  temp.q *= rhs;
  return temp;
}

// warning: might return an invalid ext_hg_complex, e.g. 0/(0,1)=(0,0)
ext_hg_complex& operator/(hg_complex lhs, const ext_hg_complex& rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp.p = lhs * rhs.q;
  temp.q = rhs.p;
  return temp;
}

// warning: might return an invalid ext_hg_complex, e.g. (0,1)/(0,1)=(0,0)
ext_hg_complex& operator/(const ext_hg_complex& lhs, const ext_hg_complex& rhs)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  temp.p = lhs.p * rhs.q;
  temp.q = lhs.q * rhs.p;
  return temp;
}

// warning: might return an invalid ext_hg_complex, e.g. (1,0)*0=(0,0)
ext_hg_complex& ext_hg_complex::operator*=(hg_complex s)
{
  p *= s;
  return *this;
}

// warning: might return an invalid ext_hg_complex, e.g. (1,0)*(0,1)=(0,0)
ext_hg_complex& ext_hg_complex::operator*=(const ext_hg_complex &s)
{
  p *= s.p;
  q *= s.q;
  return *this;
}

ext_hg_complex& ext_hg_complex::operator+=(hg_complex s)
{
  p += s*q;
  return *this;
}

ext_hg_complex& ext_hg_complex::operator-=(hg_complex s)
{
  p -= s*q;
  return *this;
}

// warning: might return an invalid ext_hg_complex, e.g. (0,1)/0=(0,0)
ext_hg_complex& ext_hg_complex::operator/=(hg_complex s)
{
  q *= s;
  return *this;
}

// warning: might return an invalid ext_hg_complex, e.g. (0,1)/(0,1)=(0,0)
ext_hg_complex& ext_hg_complex::operator/=(const ext_hg_complex& s)
{
  p *= s.q;
  q *= s.p;
  return *this;
}

ext_hg_complex& ext_hg_complex::operator=(hg_complex s)
{
  p = s; q = 1;
  return *this;
}

ostream& operator << (ostream& os, const ext_hg_complex& s)
{
  if(s.is_valid()){
    if(is_zero(s.q)){
      return os << "infinity";
    } else {
      hg_complex z = s.chart_at_zero();
      // return os << z.real() << "+" << z.imag() << "i";
      // pretty printing stuff, unfinished
      bool im = is_zero(z.imag()), re = is_zero(z.real());
      if(im && re){
	return os << "0";
      }
      if(re && !im){
	if(is_zero(z.imag()-1)) return os << "i";
	if(is_zero(z.imag()+1)) return os << "-i";
	return os << z.imag() << "i";
      }
      if(im && !re){
	return os << z.real();
      }
      if(is_zero(z.imag()-1)) return os << z.real() << "+i";
      if(is_zero(z.imag()+1)) return os << z.real() << "-i";
      if(z.imag()<0) return os << z.real() << "-" << -z.imag() << "i";
      return os << z.real() << "+" << z.imag() << "i";
    }
  } else {
    return os << "0/0";
  }
}

bool ext_hg_complex::is_valid() const
{
  return !is_zero(p) || !is_zero(q);
}

// warning: might return is_nan
hg_complex ext_hg_complex::chart_at_zero() const
{
  return p/q;
}

// warning: might return is_nan
hg_complex ext_hg_complex::chart_at_infinity() const
{
  return q/p;
}

// warning: might return is_nan
hg_complex chart_at_zero(const ext_hg_complex& s)
{
  return s.p/s.q;
}

// warning: might return is_nan
hg_complex chart_at_infinity(const ext_hg_complex& s)
{
  return s.q/s.p;
}

ext_hg_complex& ext_hg_complex::force_valid()
{
  if(!(*this).is_valid()) *this = 0;
  return *this;
}

ext_hg_complex& force_valid(const ext_hg_complex &s)
{
  ext_hg_complex& temp = get_ext_hg_complex_temp();
  return temp.force_valid();
}
