/*

Newton Solver Implementation

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

#include "common/common.hpp"
#include "common/newton.hpp"
#include "common/commonmaths.hpp"
#include<complex>

using namespace std;

hg_real newton::def_value_accuracy = 0.0000000000001;
hg_real newton::def_parameter_accuracy = 0.0000001;
hg_real newton::def_epsilon = 0.00000001;
int newton::def_maxiter = 100;

// newton solver, accuracy is the accuracy of the final result, epsilon is the
// value used in estimating f' and maxiter is the maximum number of iterations
// before giving up

hg_complex newton::solve(hg_complex (*fn)(hg_complex), hg_complex z0, hg_real value_accuracy, hg_real parameter_accuracy, hg_real epsilon, int maxiter)
{
  hg_complex z1 = z0, z2 = z0;
  hg_complex fz1, fz2;
  int n = 0;
  fz1 = fn(z1);
  fz2 = fn(z2);
  while((abs(fz1)>value_accuracy || abs(z1-z2)>parameter_accuracy) && n++<maxiter){
    z2 = z1;
    fz2 = fz1;
    z1 = z1-fz1/((fn(z1+epsilon)-fz1)/epsilon);
    fz1 = fn(z1);
  }
  return z1;
}

hg_complex newton::solve(hg_complex (*fn)(hg_complex), hg_complex z0)
{
  using namespace newton;
  return solve(fn,z0,def_value_accuracy, def_parameter_accuracy, def_epsilon, def_maxiter);
}

hg_complex newton::solve_analytic(hg_complex (*fn)(hg_complex), hg_complex z0, hg_real value_accuracy, hg_real parameter_accuracy, hg_real epsilon, int maxiter)
{
  hg_complex z1 = z0, z2 = z0;
  hg_complex fz1, fz2;
  int n = 0;
  fz1 = fn(z1);
  fz2 = fn(z2);
  while((abs(fz1)>value_accuracy || abs(z1-z2)>parameter_accuracy) && n++<maxiter){
    z2 = z1;
    fz2 = fz1;
    hg_complex fndash,iepsilon=imagunit*epsilon;
    fndash = (fn(z1+epsilon)-fn(z1-epsilon))/epsilon;
    fndash += (fn(z1+iepsilon)-fn(z1-iepsilon))/iepsilon;
    fndash *= 0.25;
    z1 = z1-fz1/fndash;
    fz1 = fn(z1);
  }
  return z1;
}

hg_complex newton::solve_analytic(hg_complex (*fn)(hg_complex), hg_complex z0)
{
  using namespace newton;
  return solve_analytic(fn,z0,def_value_accuracy, def_parameter_accuracy, def_epsilon, def_maxiter);
}

hg_complex newton::solve(hg_complex (*fn)(hg_complex), hg_complex (*fndash)(hg_complex), hg_complex z0, hg_real value_accuracy, hg_real parameter_accuracy, int maxiter)
{
  hg_complex z1 = z0, z2 = z0;
  hg_complex fz1, fz2;
  int n = 0;
  fz1 = fn(z1);
  fz2 = fn(z2);
  while((abs(fz1)>value_accuracy || abs(z1-z2)>parameter_accuracy) && n++<maxiter){
    z2 = z1;
    fz2 = fz1;
    z1 = z1-fz1/fndash(z1);
    fz1 = fn(z1);
  }
  return z1;
}

hg_complex newton::solve(hg_complex (*fn)(hg_complex), hg_complex (*fndash)(hg_complex), hg_complex z0)
{
  using namespace newton;
  return solve(fn,fndash,z0,def_value_accuracy, def_parameter_accuracy, def_maxiter);
}
