/*

Common Maths Implementation

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

#include "common/common.hpp"
#include "common/commonmaths.hpp"
#include<complex>
#include<float.h>

using namespace std;

hg_complex imagunit(0,1);

bool is_zero(hg_complex s)
{
  //  return abs(s)<=numeric_limits<hg_real>::min(); // strict c++ way of doing it
  return abs(s)<=hg_real_epsilon;
}

bool is_zero(hg_real s)
{
  //  return abs(s)<=numeric_limits<hg_real>::min(); // strict c++ way of doing it
  return abs(s)<=hg_real_epsilon;
}

hg_complex tanh(hg_complex z)
{
  return sinh(z)/cosh(z);
}

hg_complex asin(hg_complex z)
{
  return -imagunit*log(imagunit*z+sqrt((hg_complex)1.0-z*z));
}
