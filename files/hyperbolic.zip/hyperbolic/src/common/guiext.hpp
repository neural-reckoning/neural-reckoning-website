/*

  Some Allegro Gui Extensions

*/

#ifndef HG_ALLEG_GUI_EXT_H
#define HG_ALLEG_GUI_EXT_H

#include "common/common.hpp"
#include<allegro.h>

#define COL_BLACK       0
#define COL_WHITE       makecol(255,255,255)
#define COL_GUI_FG      makecol(0,0,0)
#define COL_GUI_BG      makecol(200,200,255)
#define COL_GUI_MG      makecol(128,128,128)
#define COL_GUI_EDIT_BG makecol(255,255,255)
#define COL_GUI_EDIT_FG makecol(0,0,0)
#define COL_GUI_SELECT  makecol(0,0,255)

#define DIALOG_PROC(proc,x,y,w,h,key,flags,d1,d2,dp,dp2,dp3) {proc,x,y,w,h,COL_GUI_FG,COL_GUI_BG,key,flags,d1,d2,(void*)dp,(void*)dp2,(void*)dp3}
#define EDIT_PROC(x,y,w,h,maxlen,title) { d_edit_proc, x,y,w,h,COL_GUI_EDIT_FG,COL_GUI_EDIT_BG,0,0,maxlen,0,(void*)title,NULL,NULL }
#define SIMPLE_PROC(proc,x,y,w,h,dp) DIALOG_PROC(proc,x,y,w,h,0,0,0,0,dp,NULL,NULL)
#define KEYBOARD_PROC(keycode,function) { d_keyboard_proc,0,0,0,0,0,0,0,0,keycode,0,(void*)function,NULL,NULL }
#define AUTO_TEXT_PROC(x,y,text) { d_text_proc, x,y,gui_strlen(text),11,COL_GUI_FG,COL_GUI_BG,0,0,0,0,(void*)text,NULL,NULL }
#define TEXT_PROC(x,y,w,h,text) { d_text_proc, x,y,w,h,COL_GUI_FG,COL_GUI_BG,0,0,0,0,(void*)text,NULL,NULL }
#define END_DIALOG {NULL,0,0,0,0,0,0,0,0,0,0,(void*)0,(void*)0,(void*)0}

#endif
