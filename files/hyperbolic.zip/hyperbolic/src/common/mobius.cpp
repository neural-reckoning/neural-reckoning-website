/*

Mobius Map Routines Implementation

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

#include "common/mobius.hpp"
#include "common/commonmaths.hpp"
#include "common/extcomplex.hpp"
#include<iostream>

using namespace std;

const int max_mobius_temp = 128;

mobius& get_mobius_temp()
{
  static int nbuf = 0;
  static mobius buf[max_mobius_temp];
  if(nbuf==max_mobius_temp) nbuf = 0;
  return buf[nbuf++];
}

mobius& operator*(const mobius &lhs, const mobius &rhs)
{
  mobius& m = get_mobius_temp();
  m.a = lhs.a*rhs.a+lhs.b*rhs.c; m.b = lhs.a*rhs.b+lhs.b*rhs.d;
  m.c = lhs.c*rhs.a+lhs.d*rhs.c; m.d = lhs.c*rhs.b+lhs.d*rhs.d;
  return m;
}

mobius& operator*(const mobius &lhs, hg_complex rhs)
{
  mobius& m = get_mobius_temp();
  m.a = lhs.a*rhs;
  m.b = lhs.b*rhs;
  m.c = lhs.c*rhs;
  m.d = lhs.d*rhs;
  return m;
}

mobius& operator*(hg_complex lhs, const mobius &rhs)
{
  mobius& m = get_mobius_temp();
  m.a = lhs*rhs.a;
  m.b = lhs*rhs.b;
  m.c = lhs*rhs.c;
  m.d = lhs*rhs.d;
  return m;
}

mobius& operator/(const mobius &lhs, hg_complex rhs)
{
  mobius& m = get_mobius_temp();
  m.a = lhs.a/rhs;
  m.b = lhs.b/rhs;
  m.c = lhs.c/rhs;
  m.d = lhs.d/rhs;
  return m;
}

mobius& mobius::operator*=(const mobius &m)
{
  mobius& temp = get_mobius_temp();
  temp = *this;
  a = temp.a*m.a + temp.b*m.c; b = temp.a*m.b + temp.b*m.d;
  c = temp.c*m.a + temp.d*m.c; d = temp.c*m.b + temp.d*m.d;
  return *this;
}

mobius& mobius::operator*=(hg_complex s)
{
  a*=s; b*=s; c*=s; d*=s;
  return *this;
}

mobius& mobius::operator/=(hg_complex s)
{
  a/=s; b/=s; c/=s; d/=s;
  return *this;
}

hg_complex mobius::operator() (hg_complex s) const
{
  return (a*s+b)/(c*s+d);
}

ext_hg_complex& mobius::operator() (ext_hg_complex &s) const
{
  // force_valid needs to be there so that s=1/0 is handled properly
  // in that case, 0*s=0 is what you want, otherwise the force_valid
  // has no effect at all
  return ((a*s).force_valid()+b)/((c*s).force_valid()+d);
}

mobius& operator^(mobius& m, int n)
{
  mobius& temp = get_mobius_temp();
  temp = m;
  temp.pow(n);
  return temp;
}

mobius& mobius::operator^=(int n)
{
  return pow(n);
}

ostream& operator << (ostream &os, const mobius &m)
{
  ext_hg_complex a(m.a), b(m.b), c(m.c), d(m.d);
  return os << "z |-> ((" << a << ")z+" << b << ")/((" << c << ")z+" << d << ")";
}

hg_complex mobius::trace() const
{
  return a+d;
}

hg_complex trace(const mobius &m)
{
  return m.a+m.d;
}

mobius& commutator(const mobius& a, const mobius& b)
{
  return a*b*inverse(a)*inverse(b);
}

hg_complex mobius::det() const
{
  return a*d-b*c;
}

hg_complex det(const mobius &m)
{
  return m.a*m.d-m.b*m.c;
}

mobius& mobius::set(hg_complex A, hg_complex B, hg_complex C, hg_complex D)
{
  a = A; b = B; c = C; d = D;
  return *this;
}

mobius& mobius::normalise()
{
  *this /= det();
  return *this;
}

mobius& mobius::invert()
{
  hg_complex temp;
  temp = d;
  d = a; a = temp;
  c = -c; b = -b;
  (*this)/=det();
  return *this;
}

mobius& inverse(const mobius &m)
{
  mobius& temp = get_mobius_temp();
  temp = m;
  temp.invert();
  return temp;
}

mobius& mobius::pow(int n)
{
  if(n==1) return *this;
  if(n==0){
    a = d = 1.0;
    b = c = 0.0;
    return *this;
  }
  if(n<0){
    invert();
    n = -n;
  }
  mobius& temp = get_mobius_temp();
  temp = *this;
  for(int i=1;i<n;i++){
    *this *= temp;
  }
  return *this;
}

mobius& pow(const mobius &m, int n)
{
  mobius &temp = get_mobius_temp();
  temp = m;
  temp.pow(n);
  return temp;
}

hg_complex mobius::apply(hg_complex s) const
{
  return (*this)(s);
}

ext_hg_complex& mobius::apply(ext_hg_complex& s) const
{
  return (*this)(s);
}

hg_complex apply(mobius &m, hg_complex s)
{
  return m(s);
}

ext_hg_complex& apply(mobius &m, ext_hg_complex &s)
{
  return m(s);
}
