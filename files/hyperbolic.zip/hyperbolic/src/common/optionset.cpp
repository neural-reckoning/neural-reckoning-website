// optionset.cpp - a class to read and store options for a command line
// program either from the command line or from a file

#include "common/common.hpp"
#include<cstring>
#include "common/optionset.hpp"
#include "common/commonmaths.hpp"
#include<iostream>
#include<string>

using namespace std;

void oc_hg_real(void* var_addr, char* string_rep)
{
  *((hg_real*)var_addr) = atof(string_rep);
}

void oc_charptr(void* var_addr, char* string_rep)
{
  *((char**)var_addr) = string_rep;
}

void oc_int(void* var_addr, char* string_rep)
{
  *((int*)var_addr) = atoi(string_rep);
}

void oc_bool(void* var_addr, char* string_rep)
{
  //if(string_rep[0]=='\0') *((bool*)var_addr) = true;
  //else *((bool*)var_addr) = atoi(string_rep);
  *((bool*)var_addr) = true;
}

void oc_boolnot(void* var_addr, char* string_rep)
{
  //if(string_rep[0]=='\0') *((bool*)var_addr) = false;
  //else *((bool*)var_addr) = !atoi(string_rep);
  *((bool*)var_addr) = false;
}

void oc_string(void* var_addr, char* string_rep)
{
	((std::string *)var_addr)->assign(string_rep);
}

void optionset::initialise(option* optlist)
{
  helptext = "";
  for(option* o = optlist;(*o).var_addr!=0;o++){
    opt[(*o).var_id]=*o;
  }
}

bool optionset::read_options(int &argc, char ** &argv)
{
	for(int i=1;i<argc;i++)
	{
		if(argv[i][0]=='-')
		{
#ifdef WIN32
			if(stricmp(argv[i],"-h")==0 || stricmp(argv[i],"-help")==0 || stricmp(argv[i],"--help")==0)
			{
#else
			if(strcasecmp(argv[i],"-h")==0 || strcasecmp(argv[i],"-help")==0 || strcasecmp(argv[i],"--help")==0)
			{
#endif
				cout << "Usage: " << argv[0] << " [switches]" << endl << endl;
				if(helptext[0]!=0) cout << helptext << endl << endl;
				cout << "Switches are the of form [-switch [value]]." << endl;
				cout << "Available switches (with default values):" << endl << endl;
				for(map<string,option>::iterator j=opt.begin();j!=opt.end();j++)
				{
					option &o = (*j).second;
					if(o.var_fn==oc_bool)
					{
						cout << "  " << o.var_id << ", not" << o.var_id << " (default = ";
						if(atoi(o.var_default.c_str())) cout << o.var_id;
						else cout << "not" << o.var_id;
						cout << ")\n    " << o.var_desc << endl;
						cout << endl;
					} else if(o.var_fn!=oc_boolnot)
					{
						cout << "  " << o.var_id << " = " << o.var_default << "\n    " << o.var_desc << endl << endl;
					}
				}
				return false;
			}
			if(i<(argc-1))
			{
				if(argv[i+1][0]=='-')
				{
					option o = opt[string(++argv[i])];
					if(o.var_addr) o.var_fn(o.var_addr,"");
				} else
				{
					option o = opt[string(++argv[i])];
					if(o.var_addr) o.var_fn(o.var_addr,argv[++i]);
				}
			} else
			{
				option o = opt[string(++argv[i])];
				if(o.var_addr) o.var_fn(o.var_addr,"");
			}
		}
	}
	return true;
}

bool parse_options(option* optlist, int &argc, char ** &argv)
{
  optionset oset(optlist);
  return oset.read_options(argc,argv);
}

bool parse_options(option* optlist, char* helptext, int &argc, char ** &argv)
{
  optionset oset(optlist,helptext);
  return oset.read_options(argc,argv);
}
