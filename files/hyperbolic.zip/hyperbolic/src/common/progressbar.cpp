/*

Progress Bar Implementation

Hyperbolic Geometry Routines
(c) Dan Goodman 2002

 */

#include "common/common.hpp"
#include "common/progressbar.hpp"
#include<iostream>

using namespace std;

void text_progress_bar::finished()
{
  (*os) << "finished.\n";
  (*os).flush();
}

void text_progress_bar::update()
{
  if(current_jump()==0){
    (*os) << message << endl;
  }
  (*os) << (100*current_jump())/max_jump() << "% ";
  (*os).flush();
}

int progress_bar::set(const int Current)
{
  if(Current == 0){
    current = 0;
    nextjump = max/numjumps;
    currentjump = 0;
    update();
  } else {
    current = Current;
    while(current>=nextjump && current<max){
      currentjump++;
      nextjump = (max*currentjump)/numjumps;
      update();
    }
  }
  return current;
}