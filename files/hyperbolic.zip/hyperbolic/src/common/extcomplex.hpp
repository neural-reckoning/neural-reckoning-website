/*

Extended hg_complexs Header

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

/* Extended hg_complex class, i.e. S^1
 * implemented using S^1 homeo to CP^1=(C*C-0)/(C-0)
 */

/*

As for the mobius maps, arithmetic operators are implemented as expected
using a static buffer. There is a stream operator <<. Functions provided are:

is_valid() tells you if the hg_complex is not equal to 0/0
force_valid() changes 0/0 to 0/1 if it occurs
chart_at_zero() returns p/q as a hg_complex (valid for all p/q!=1/0)
chart_at_infinity() return q/p as a hg_complex (valid for all p/q!=0/1)

 */

#ifndef HG_EXThg_complex_H
#define HG_EXThg_complex_H

#include "common/commonmaths.hpp"
#include<iostream>

class ext_hg_complex
{
 public:
  // data
  hg_complex p,q; // p/q essentially
  // constructors
  ext_hg_complex() : p(0), q(1) {}
  ext_hg_complex(hg_complex P) : p(P), q(1) {}
  ext_hg_complex(hg_complex P, hg_complex Q) : p(P), q(Q) {}
  // operators
  friend ext_hg_complex& operator+(const ext_hg_complex& lhs, hg_complex rhs);
  friend ext_hg_complex& operator+(hg_complex lhs, const ext_hg_complex& rhs);
  friend ext_hg_complex& operator-(const ext_hg_complex& lhs, hg_complex rhs);
  friend ext_hg_complex& operator-(hg_complex lhs, const ext_hg_complex& rhs);
  friend ext_hg_complex& operator*(const ext_hg_complex& lhs, hg_complex rhs);
  friend ext_hg_complex& operator*(hg_complex lhs, const ext_hg_complex &rhs);
  friend ext_hg_complex& operator*(const ext_hg_complex& lhs, const ext_hg_complex &rhs);
  friend ext_hg_complex& operator/(const ext_hg_complex& lhs, hg_complex rhs);
  friend ext_hg_complex& operator/(hg_complex lhs, const ext_hg_complex& rhs);
  friend ext_hg_complex& operator/(const ext_hg_complex& lhs, const ext_hg_complex& rhs);
  ext_hg_complex& operator*=(hg_complex s);
  ext_hg_complex& operator*=(const ext_hg_complex &s);
  ext_hg_complex& operator+=(hg_complex s);
  ext_hg_complex& operator-=(hg_complex s);
  ext_hg_complex& operator/=(hg_complex s);
  ext_hg_complex& operator/=(const ext_hg_complex &s);
  ext_hg_complex& operator=(hg_complex s);
  operator hg_complex() { return p/q; } // might generate is_nan
  friend std::ostream& operator<< (std::ostream &os, const ext_hg_complex& s);
  // functions
  bool is_valid() const; // returns true if p, q not both zero
  ext_hg_complex& force_valid(); // makes an invalid ext_hg_complex into 0/1
  friend ext_hg_complex& force_valid(const ext_hg_complex& s);
  hg_complex chart_at_zero() const;
  hg_complex chart_at_infinity() const;
  friend hg_complex chart_at_zero(const ext_hg_complex& s);
  friend hg_complex chart_at_infinity(const ext_hg_complex& s);
};

#endif
