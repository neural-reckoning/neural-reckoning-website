/*

Progress Bar Header

Hyperbolic Geometry Routines
(c) Dan Goodman 2002

 */

#ifndef HG_PROGRESS_BAR_H
#define HG_PROGRESS_BAR_H

#include "common/common.hpp"
#include<iostream>
#include<string>

// progress bar is a class which does most of the work except actually
// displaying the progress, to do that you must override the update() and finished()
// virtual functions
class progress_bar
{
  int max, current;
  int numjumps;
  int nextjump;
  int currentjump;
protected:
  virtual void update() {} // displays the current indicator
  int current_val() { return current; }
  int max_val() { return max; }
  int current_jump() { return currentjump; }
  int max_jump() { return numjumps; }
  std::string message;
public:
  progress_bar() : max(100), current(0), numjumps(10), nextjump(10), currentjump(0) {}
  void set_max(int Max) { max = Max; }
  void set_numjumps(int Numjumps) { numjumps = Numjumps; }
  void set_message(const std::string& s) { message = s; }
  virtual void finished() {}
  int set(const int Current);
  int operator++ (int) { return (*this).set(current+1); }
};

// text progress bar, prints out a percentage to an ostream
class text_progress_bar : public progress_bar
{
  std::ostream *os;
protected:
  virtual void update();
public:
  virtual void finished();
  void set_ostream(std::ostream& OS) { os = &OS; }
};

// text progress bar, prints to cout
class std_text_progress_bar : public text_progress_bar
{
public:
  std_text_progress_bar() { set_ostream(std::cout); }
};

#endif
