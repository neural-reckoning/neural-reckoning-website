/*

Graphics Wrapper Header

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

#ifndef HG_GFX_WRAPPER_H
#define HG_GFX_WRAPPER_H

#include "common/common.hpp"
//#include<cgraph.h>
#include<list>
#include<utility>
#include<fstream>
#include "common/commonmaths.hpp"

#define GFXWRAPPER(type,name) type##_gfx_wrapper real##name; gfx_wrapper &name = real##name;

// this virtual base class contains the abstract functions which are
// implemented by derived classes

class gfx_wrapper
{
protected:
  hg_real Xmin, Xmax, Ymin, Ymax;
public:
  gfx_wrapper() { Xmin=Ymin=0.0; Ymax=Ymax=1.0; }
  // sets the dimensions which will be viewable
  virtual void set_view_dimensions(hg_real xmin, hg_real ymin, hg_real xmax, hg_real ymax);
  // sets the dimensions of the output in whatever units are appropriate
  virtual void set_output_dimensions(hg_real width, hg_real height) = 0;
  // set the output filename (should be done before initialising the
  // the output device because the output may save as it goes along)
  virtual void set_output_filename(const char* filename) = 0;
  // initialises the output device (returns true on success)
  virtual bool initialise() = 0;
  // finished with the output device (save may be optional or not)
  virtual void finished(bool save) = 0;
  // clears the image
  virtual void clear() = 0;
  // sets the pen colour
  virtual void colour(hg_real r, hg_real g, hg_real b) = 0;
  // plots a point at the specified coordinates
  virtual void point(hg_real x, hg_real y) = 0;
  void point(hg_complex z) { point(z.real(),z.imag()); }
  // draws the specified line immediately
  virtual void line(hg_real x1, hg_real y1, hg_real x2, hg_real y2) = 0;
  void line(hg_complex z1, hg_complex z2) { line(z1.real(),z1.imag(),z2.real(),z2.imag()); }
  // draws an unfilled circle immediately
  virtual void circle(hg_real x, hg_real y, hg_real rad) = 0;
  void circle(hg_complex z, hg_real rad) { circle(z.real(),z.imag(),rad); }
  // draws a filled circle immediately
  virtual void circlefill(hg_real x, hg_real y, hg_real rad) = 0;
  void circlefill(hg_complex z, hg_real rad) { circlefill(z.real(),z.imag(),rad); }
  // moves the pen
  virtual void moveto(hg_real x, hg_real y) = 0;
  void moveto(hg_complex z) { moveto(z.real(),z.imag()); }
  // queues a line to
  virtual void lineto(hg_real x, hg_real y) = 0;
  void lineto(hg_complex z) { lineto(z.real(),z.imag()); }
  // strokes the queued path
  virtual void stroke() = 0;
  // fills the queued path
  virtual void fill() = 0;
};

// null gfx wrapper does nothing in response to all commands
class null_gfx_wrapper : public gfx_wrapper
{
  virtual void set_output_dimensions(hg_real width, hg_real height) {}
  virtual void set_output_filename(const char* filename) {}
  virtual bool initialise() { return true; }
  virtual void finished(bool save) {}
  virtual void clear() {}
  virtual void colour(hg_real r, hg_real g, hg_real b) {}
  virtual void point(hg_real x, hg_real y) {}
  virtual void line(hg_real x1, hg_real y1, hg_real x2, hg_real y2) {}
  virtual void circle(hg_real x, hg_real y, hg_real rad) {}
  virtual void circlefill(hg_real x, hg_real y, hg_real rad) {}
  virtual void moveto(hg_real x, hg_real y) {}
  virtual void lineto(hg_real x, hg_real y) {}
  virtual void stroke() {}
  virtual void fill() {}
};

// portable postscript graphics wrapper
class postscript_gfx_wrapper : public gfx_wrapper
{
  char Filename[256];
  hg_real Width, Height;
  hg_real Scale, Xoff, Yoff;
  inline hg_real Xc(hg_real x);
  inline hg_real Yc(hg_real y);
  std::ofstream File;
public:
  virtual void set_output_dimensions(hg_real width, hg_real height);
  virtual void set_output_filename(const char* filename);
  virtual bool initialise();
  virtual void finished(bool save);
  virtual void clear();
  virtual void colour(hg_real r, hg_real g, hg_real b);
  virtual void point(hg_real x, hg_real y);
  virtual void line(hg_real x1, hg_real y1, hg_real x2, hg_real y2);
  virtual void circle(hg_real x, hg_real y, hg_real rad);
  virtual void circlefill(hg_real x, hg_real y, hg_real rad);
  virtual void moveto(hg_real x, hg_real y);
  virtual void lineto(hg_real x, hg_real y);
  virtual void stroke();
  virtual void fill();
};

#endif