/*

Newton Solver Header

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman


Comments scattered throughout

 */

#ifndef HG_NEWTON_H
#define HG_NEWTON_H

#include "common/common.hpp"
#include "common/commonmaths.hpp"

namespace newton
{
  // newton solvers use either function pointers of type hg_complex (*)(hg_complex)
  // or are template functions which act on classes with an () operator
  // defined

  // some global default variables

  extern hg_real def_value_accuracy;
  extern hg_real def_parameter_accuracy;
  extern hg_real def_epsilon;
  extern int def_maxiter;

  /* function pointer solvers

  Example use:

  hg_complex f(hg_complex z) { return z*z-z; }
  ...
  hg_complex z = newton::solve_analytic(f,1);

  or more accurately:
  hg_complex f(hg_complex z) { return z*z - z; }
  hg_complex fdash(hg_complex z) { return 2*z-1; }
  ...
  hg_complex z = newton::solve(f,fdash,1);

  value_accuracy is the accuracy required in the value f(z)
  parameter_accuracy is the accuracy required in the returned value z
  epsilon (when used) is the infinitessimal used to approximate the derivative

   */

  struct params
  {
    hg_real value_accuracy;
    hg_real parameter_accuracy;
    hg_real epsilon;
    int maxiter;
  };

  // solve using default approximate differentiation (i.e. C1)
  hg_complex solve(hg_complex (*fn)(hg_complex), hg_complex z0, hg_real value_accuracy, hg_real parameter_accuracy, hg_real epsilon, int maxiter);
  inline hg_complex solve(hg_complex (*fn)(hg_complex), hg_complex z0, const params& p)
  {
    return solve(fn,z0,p.value_accuracy,p.parameter_accuracy,p.epsilon,p.maxiter);
  }
  hg_complex solve(hg_complex (*fn)(hg_complex), hg_complex z0); // use defaults
  // solve using analytic approximate differentiation
  hg_complex solve_analytic(hg_complex (*fn)(hg_complex), hg_complex z0, hg_real value_accuracy, hg_real parameter_accuracy, hg_real epsilon, int maxiter);
  inline hg_complex solve_analytic(hg_complex (*fn)(hg_complex), hg_complex z0, const params& p)
  {
    return solve_analytic(fn,z0,p.value_accuracy,p.parameter_accuracy,p.epsilon,p.maxiter);
  }
  hg_complex solve_analytic(hg_complex (*fn)(hg_complex), hg_complex z0); // use defaults
  // solve using specified exact differential
  hg_complex solve(hg_complex (*fn)(hg_complex), hg_complex (*fndash)(hg_complex), hg_complex z0, hg_real value_accuracy, hg_real parameter_accuracy, int maxiter);
  inline hg_complex solve(hg_complex (*fn)(hg_complex), hg_complex (*fndash)(hg_complex), hg_complex z0, const params &p)
  {
    return solve(fn,fndash,z0,p.value_accuracy,p.parameter_accuracy,p.maxiter);
  }
  hg_complex solve(hg_complex (*fn)(hg_complex), hg_complex (*fndash)(hg_complex), hg_complex z0); // use defaults

  // templated function object solvers

  /*

  the tsolve class of newton solvers use function objects rather than function
  pointers. Example:

  class cosnx
  {
  public:
    int n;
    cosnx(int N) : n(N) {}
    hg_complex operator() (hg_complex z) { return cos(n*z); }
  };
  ...
  cosnx f(6);
  hg_complex z = newton::tsolve(f,1/6);

  This should return a value z s.t. cos(6z)=0

   */

  template<class fn_obj> hg_complex tsolve(fn_obj &f, hg_complex z0, hg_real value_accuracy, hg_real parameter_accuracy, hg_real epsilon, int maxiter)
  {
    hg_complex z1 = z0, z2 = z0;
    hg_complex fz1, fz2;
    int n = 0;
    fz1 = f(z1);
    fz2 = f(z2);
    while((abs(fz1)>value_accuracy || abs(z1-z2)>parameter_accuracy) && n++<maxiter){
      z2 = z1;
      fz2 = fz1;
      z1 = z1-fz1/((f(z1+epsilon)-fz1)/epsilon);
      fz1 = f(z1);
    }
    return z1;  
  }

  template<class fn_obj> inline hg_complex tsolve(fn_obj &f, hg_complex z0, params& p)
  {
    return tsolve<fn_obj>(f,z0,p.value_accuracy,p.parameter_accuracy,p.epsilon,p.maxiter);
  }

  template<class fn_obj> hg_complex tsolve(fn_obj &f, hg_complex z0)
  {
    using namespace newton;
    return tsolve<fn_obj>(f,z0,def_value_accuracy,def_parameter_accuracy,def_epsilon,def_maxiter);
  }

  template<class fn_obj> hg_complex tsolve_analytic(fn_obj &f, hg_complex z0, hg_real value_accuracy, hg_real parameter_accuracy, hg_real epsilon, int maxiter)
  {
    hg_complex z1 = z0, z2 = z0;
    hg_complex fz1, fz2;
    int n = 0;
    fz1 = f(z1);
    fz2 = f(z2);
    while((abs(fz1)>value_accuracy || abs(z1-z2)>parameter_accuracy) && n++<maxiter){
      z2 = z1;
      fz2 = fz1;
      hg_complex fndash,iepsilon=imagunit*epsilon;
      fndash = (f(z1+epsilon)-f(z1-epsilon))/epsilon;
      fndash += (f(z1+iepsilon)-f(z1-iepsilon))/iepsilon;
      fndash *= 0.25;
      z1 = z1-fz1/fndash;
      fz1 = f(z1);
    }
    return z1;
  }

  template<class fn_obj> inline hg_complex tsolve_analytic(fn_obj &f, hg_complex z0, params& p)
  {
    return tsolve_analytic<fn_obj>(f,z0,p.value_accuracy,p.parameter_accuracy,p.epsilon,p.maxiter);
  }

  template<class fn_obj> hg_complex tsolve_analytic(fn_obj &f, hg_complex z0)
  {
    using namespace newton;
    return tsolve_analytic<fn_obj>(f,z0,def_value_accuracy,def_parameter_accuracy,def_epsilon,def_maxiter);
  }

  template<class fn_obj1, class fn_obj2> hg_complex tsolve(fn_obj1 &f, fn_obj2 &fdash, hg_complex z0, hg_real value_accuracy, hg_real parameter_accuracy, int maxiter)
  {
    hg_complex z1 = z0, z2 = z0;
    hg_complex fz1, fz2;
    int n = 0;
    fz1 = f(z1);
    fz2 = f(z2);
    while((abs(fz1)>value_accuracy || abs(z1-z2)>parameter_accuracy) && n++<maxiter){
      z2 = z1;
      fz2 = fz1;
      z1 = z1-fz1/fdash(z1);
      fz1 = fn(z1);
    }
    return z1;
  }

  template<class fn_obj1, class fn_obj2> inline hg_complex tsolve(fn_obj1 &f, fn_obj2 &fdash, hg_complex z0, params& p)
  {
    return tsolve<fn_obj1,fn_obj2>(f,fdash,z0,p.value_accuracy,p.parameter_accuracy,p.maxiter);
  }

  template<class fn_obj1, class fn_obj2> hg_complex tsolve(fn_obj1 &f, fn_obj2 &fdash, hg_complex z0)
  {
    using namespace newton;
    return tsolve<fn_obj1,fn_obj2>(f,fdash,z0,def_value_accuracy,def_parameter_accuracy,def_maxiter);
  }
}

#endif
