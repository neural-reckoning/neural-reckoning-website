/*

Mobius Map Routines Header

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman


Mobius map class
----------------

A mobius map is a map z |-> (az+b)/(cz+d), here a, b, c, d are hg_complexs. The
class below provides the obvious constructors, multiplication and division
operators (for hg_complexs and mobius maps), integer power operator ^. A mobius
map is a "function object" in C++ terminology, i.e. the following works as
you'd expect it to:

mobius m(1,0,0,1);
hg_complex z(1,1);
z = m(z);

Mobius maps can also act on extended hg_complexs, see below for more details.

The last operator included is the output stream operator << which outputs
a description of the map.

Functions included are:

trace (via m.trace() or trace(m))
determinant (via m.det() or det(m))
commutator (via commutator(m1,m2))
normalisation (via m.normalise() or normalised(m))
inversion (via m.invert() or inverse(m))
application (via m.apply(hg_complex or ext_hg_complex) or apply(m,hg_complex or ext_hg_complex)

Operators and functions leaving *this and the operands constant use a
temporary static buffer of mobius maps. This means an expression involving
a large number of operators will cause errors (because it will use more
temporary variables than the static buffer has space for). You can alter the
size of this static buffer by changing the value of

const int max_mobius_temp = 128;

in mobius.cpp.

 */

#ifndef HG_MOBIUS_H
#define HG_MOBIUS_H

#include "common/commonmaths.hpp"
#include "common/mobius.hpp"
#include "common/extcomplex.hpp"
#include<iostream>

class mobius;

class mobius
{
 public:
  hg_complex a,b,c,d;
  // constructors
  mobius() : a(0), b(0), c(0), d(0) {}
  mobius(hg_complex A, hg_complex B, hg_complex C, hg_complex D) : a(A), b(B), c(C), d(D) {}
  // operators
  friend mobius& operator*(const mobius &lhs, const mobius &rhs); // compose
  friend mobius& operator*(const mobius &lhs, hg_complex rhs);  // hg_complex multiply
  friend mobius& operator*(hg_complex lhs, const mobius &rhs);  // hg_complex multiply
  friend mobius& operator/(const mobius &lhs, hg_complex rhs);  // hg_complex divide
  friend mobius& operator^(const mobius &m, int n);  // integer power
  mobius& operator*=(const mobius &m);               // compose
  mobius& operator*=(hg_complex s);                      // hg_complex multiply
  mobius& operator/=(hg_complex s);                      // hg_complex divide
  mobius& operator^=(int n);                         // integer power
  hg_complex operator() (hg_complex s) const;                // apply map to hg_complex
  ext_hg_complex& operator() (ext_hg_complex &s) const;      // apply map to ext_hg_complex
  friend std::ostream& operator << (std::ostream &os, const mobius &m); // output map to a stream
  // functions
  hg_complex trace() const;                              // trace of the map
  friend hg_complex trace(const mobius &m);
  friend mobius& commutator(const mobius &a, const mobius &b); // aba^-1b^-1
  hg_complex det() const;                                // determinant
  friend hg_complex det(const mobius &m);                // determinant
  mobius& set(hg_complex A, hg_complex B, hg_complex C, hg_complex D);// set values
  mobius& normalise();                               // so that det=1
  friend mobius& normalised(const mobius &m);        // as above
  mobius& invert();                                  // invert this mobius map
  friend mobius& inverse(const mobius &m);           // invert map m
  mobius& pow(int n);                                // integer power
  friend mobius& pow(const mobius &m, int n);        // integer power
  hg_complex apply(hg_complex s) const;                      // apply map to hg_complex
  ext_hg_complex& apply(ext_hg_complex &s) const;            // apply map to ext_hg_complex
  friend hg_complex apply(mobius &m, hg_complex s);          // apply map to hg_complex
  friend ext_hg_complex& apply(mobius &m, ext_hg_complex &s);// apply map to ext_hg_complex
};

#endif
