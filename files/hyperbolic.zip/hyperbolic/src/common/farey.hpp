/*

Farey Series Header

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman


The only arithmetic operator provided for the farey rational class
is + which gives farey addition. This class also uses a static buffer.
Comparison operators are provided and test for equality (etc.) as rational
numbers not as pairs (p,q). There is a stream operator <<.

reduce() puts p/q in lowest terms

 */

#ifndef HG_FAREY_H
#define HG_FAREY_H

#include "common/common.hpp"
#include "common/commonmaths.hpp"
#include<iostream>
#include<list>
#include<vector>

class farey;

extern farey farey_0;
extern farey farey_infinity;
extern farey farey_1;

//extern const int max_farey_temp;
#define max_farey_temp 128
inline farey& get_farey_temp();

class farey
{
 public:
  // data
  hg_int p,q;
  // operators
  farey() : p(0), q(1) {}
  farey(hg_int P, hg_int Q) : p(P), q(Q) {}
  inline farey& operator+(const farey& rhs) const
  {
    farey &temp = get_farey_temp();
    temp.p = p + rhs.p;
    temp.q = q + rhs.q;
    return temp;
  }
  inline farey& operator+=(const farey& f)
  {
    p += f.p;
    q += f.q;
    return *this;
  }
  inline operator hg_real() const { return (hg_real)p/(hg_real)q; } // might return nan
  friend std::ostream& operator<< (std::ostream& os, const farey& f);
  inline bool operator==(const farey& f2) const { return p*f2.q-f2.p*q == 0; }
  inline bool operator!=(const farey& f2) const { return p*f2.q-f2.p*q != 0; }
  inline bool operator<(const farey& f2) const { return p*f2.q-f2.p*q < 0; }
  inline bool operator<=(const farey& f2) const { return p*f2.q-f2.p*q <= 0; }
  inline bool operator>(const farey& f2) const { return p*f2.q-f2.p*q > 0; }
  inline bool operator>=(const farey& f2) const { return p*f2.q-f2.p*q >= 0; }
  // functions
  farey& set(int P, int Q);
  farey& reduce();                           // reduce p/q
};

// this shouldn't really be placed here, but profiling revealed that a lot of time
// was spent inside this function, so inlining it seemed appropriate and that
// entails putting it here...
inline farey& get_farey_temp()
{
  static int nbuf = 0;
  static farey buf[max_farey_temp];
  if(nbuf==max_farey_temp) nbuf = 0;
  return buf[nbuf++];
}

// next_in_sequence gives the next element in the order maxdenom farey series
// gives the current (and previous for the first function) elements
farey& next_in_sequence(const farey& f1, const farey& f2, hg_int maxdenom);
farey& next_in_sequence(const farey& f, hg_int maxdenom);
// the next two functions give a list or vector containing the entire farey
// series of order maxdenom. The to_infinity variable indicates whether to
// consider only the series between 0 and 1 or whether to return the whole
// series from 0 to 1/0. Implementation note: the vector version just creates
// a list and then copies it into a vector so it is memory inefficient (but
// being memory efficient would be too slow)
void farey_series(std::list<farey> &seq, hg_int maxdenom, bool to_infinity);
void farey_series(std::vector<farey> &seq, hg_int maxdenom, bool to_infinity);

#endif
