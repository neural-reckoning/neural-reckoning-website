/*

Common Header

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

#ifndef HG_COMMON_H
#define HG_COMMON_H

// What compiler are we using? (Only use this if the automatic
// compiler detection below doesn't work.)

//#define HG_MSVC

// Automatic compiler detection
#ifdef _MSC_VER // always defined for MSVC compiler, but not for any other
#define HG_MSVC
#endif

// Microsoft Visual C++ specifics
#ifdef HG_MSVC
#pragma warning(disable:4786) // debug information names too long
//#define USE_CONSOLE // this allows us to the use allegro graphics and
                    // a console window, remember to link with
                    // "/subsystem:console" rather than "/subsystem:windows"
#endif

#endif