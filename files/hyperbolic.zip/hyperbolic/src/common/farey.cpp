/*

Farey Series Implementation

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

#include "common/common.hpp"
#include "common/farey.hpp"
#include<list>
#include<iostream>
#include<vector>

using namespace std;

//const int max_farey_temp = 128;

/*
inline farey& get_farey_temp()
{
  static int nbuf = 0;
  static farey buf[max_farey_temp];
  if(nbuf==max_farey_temp) nbuf = 0;
  return buf[nbuf++];
}
*/

farey farey_0(0,1);
farey farey_infinity(1,0);
farey farey_1(1,1);

/*
inline farey& farey::operator+(const farey& rhs) const
{
  farey &temp = get_farey_temp();
  temp.p = p + rhs.p;
  temp.q = q + rhs.q;
  return temp;
}

inline farey& farey::operator+=(const farey& f)
{
  p += f.p;
  q += f.q;
  return *this;
}
*/

ostream& operator<< (ostream& os, const farey& f)
{
  return os << f.p << "/" << f.q;
}

/*
inline bool farey::operator== (const farey& f2) const
{
  return p*f2.q-f2.p*q == 0;
}

inline bool farey::operator!= (const farey& f2) const
{
  return !(*this==f2);
}

inline bool farey::operator< (const farey& f2) const
{
  return p*f2.q-f2.p*q < 0;
}

inline bool farey::operator<= (const farey& f2) const
{
  return p*f2.q-f2.p*q <= 0;
}

inline bool farey::operator> (const farey& f2) const
{
  return p*f2.q-f2.p*q > 0;
}

inline bool farey::operator>= (const farey& f2) const
{
  return p*f2.q-f2.p*q >= 0;
}
*/

farey& farey::set(int P, int Q)
{
  p = P; q = Q; return *this;
}

// todo: use Euclid's algorithm instead of this horror
farey& farey::reduce()
{
  hg_int j=2;
  while( j<=p && j<=q ){
    if( p%j==0 && q%j==0 ){
      p/=j;
      q/=j;
    } else j++;
  }
  return *this;
}

// this only works for 0/1<=f1<f2<1/1
// initialise the sequence with 0/1,1/maxdenom
farey& next_in_sequence(const farey& f1, const farey& f2, hg_int maxdenom)
{
//  if(f1==farey(maxdenom-2,maxdenom-1)&&f2==farey(maxdenom-1,maxdenom)) return farey_1;
  farey& temp = get_farey_temp();
  hg_int x = (maxdenom + f1.q) / f2.q;
  temp.p = x * f2.p - f1.p;
  temp.q = x * f2.q - f1.q;
  return temp;
}

// hack algorithm, but it only needs to run once per calculation
farey& next_in_sequence(const farey& f, hg_int maxdenom)
{
  farey& ret = get_farey_temp();
  farey& temp = get_farey_temp();
  ret = farey_1;
  hg_int i,j;
  for(j=1;j<=maxdenom;j++)
    for(i=0;i<=j;i++){
      temp.set(i,j);
      if(temp<ret && temp>f) ret=temp;
    }
  return ret;
}

// algorithm from Indra's pearls, could be written better given the
// farey series helper functions
// todo: this doesn't work
/*farey& next_in_sequence(const farey& f, int maxdenom)
{
  farey& ret = get_farey_temp();
  farey& f1 = get_farey_temp();
  farey& f2 = get_farey_temp();
  farey& rs = get_farey_temp();
  farey& temp = get_farey_temp();

  f1 = farey_0;
  f2 = farey_infinity;
  rs = f;
  hg_int sign = -1;

  while(rs.q){
    hg_int a = rs.p/rs.q;
    rs.set(rs.q,rs.p-a*rs.q);
    temp = f2;
    f2.set(a*f2.p+f1.p,a*f2.q+f1.q);
    f1 = temp;
    sign = -sign;
  }
  hg_int k = (maxdenom-sign*f1.q)/maxdenom;
  ret.set(k*f.p+sign*f1.p,k*f.q+sign*f1.q);
  //cerr << ret;
  //cerr << maxdenom;
  return ret;
}*/

void farey_series(list<farey> &seq, int maxdenom, bool to_infinity)
{
  farey f1, f2, f3;
  f1.set(0,1);
  f2.set(1,maxdenom);
  f3.set(0,1);
  seq.clear();
  seq.push_back(f1);
  seq.push_back(f2);
  while(f3.p<f3.q){
    f3 = next_in_sequence(f1,f2,maxdenom);
    f1 = f2;
    f2 = f3;
    seq.push_back(f3);
  }
  if(to_infinity){
    list<farey>::reverse_iterator i = seq.rbegin();
    i++;
    while(i!=seq.rend()){
      f1 = *i;
      f2.p = f1.q;
      f2.q = f1.p;
      seq.push_back(f2);
      i++;
    }
  }
}

// inefficient, but if you really want the series in a vector rather than
// a list then this is the fastest way of doing it without knowing the
// size of the sequence beforehand
void farey_series(vector<farey> &seq, int maxdenom, bool to_infinity)
{
  list<farey> lseq;
  farey_series(lseq,maxdenom,to_infinity);
  seq.clear();
  seq.reserve(lseq.size());
  list<farey>::iterator i;
  for(i=lseq.begin();i!=lseq.end();i++){
    seq.push_back(*i);
  }
}
