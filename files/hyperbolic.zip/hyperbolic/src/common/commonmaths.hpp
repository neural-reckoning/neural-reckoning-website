/*

Common Maths Header

Hyperbolic Geometry Routines
(c) 2002 Dan Goodman

 */

#ifndef HG_COMMON_MATHS_H
#define HG_COMMON_MATHS_H

#include "common/common.hpp"
#include<complex>

typedef double hg_real;
typedef std::complex<hg_real> hg_complex;
typedef int hg_int;

#define hg_real_epsilon DBL_EPSILON

extern hg_complex imagunit;

bool is_zero(hg_complex s); // return true if abs(s)<DBL_EPSILON
bool is_zero(hg_real s);

hg_complex tanh(hg_complex z);
hg_complex asin(hg_complex z);

#endif
