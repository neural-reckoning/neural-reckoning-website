// optionset.h - a class to read and store options for a command line
// program either from the command line or from a file

#ifndef OPTIONSET_H
#define OPTIONSET_H

#include "common/common.hpp"
#include "common/commonmaths.hpp"
#include<map>
#include<string>
#include<sstream>

using namespace std;

template<class C>
string optionset_makestring(C &val)
{
  ostringstream s;
  s << val;
  return s.str();
}

#define BEGINLISTOPTION(listname) option listname[] = {
#define LISTOPTION(var_type, var_name, var_id, var_fn, var_desc) option((void *)&var_name, var_id, var_fn, var_desc, optionset_makestring<var_type>(var_name)),
#define BOOLLISTOPTION(var_name, var_id, var_desc) LISTOPTION(bool,var_name,var_id,oc_bool,var_desc) LISTOPTION(bool,var_name,"not" var_id,oc_boolnot,var_desc)
#define ENDLISTOPTION option(0,0,0,0,string(""))};

void oc_hg_real(void*,char*);
void oc_charptr(void*,char*);
void oc_int(void*,char*);
void oc_bool(void*,char*);
void oc_boolnot(void*,char*);
void oc_string(void*,char*);

struct option
{
  void* var_addr;                  // address of the variable
  char* var_id;                    // string identifier
  void (*var_fn)(void*, char*);    // conversion function (arguments are the address of the variable and a string representation of the variable)
  char* var_desc;                  // description
  string var_default;              // default value
  option() : var_addr(0), var_id(0), var_fn(0), var_desc(0) {}
  option(void* Var_Addr, char* Var_Id, void (*Var_Fn)(void*,char*), char* Var_Desc, string Var_Default) : var_addr(Var_Addr), var_id(Var_Id), var_fn(Var_Fn), var_desc(Var_Desc), var_default(Var_Default) {}
};

class optionset
{
 public:
  map<string,option> opt;
  char* helptext;
  optionset() { opt.clear(); helptext=""; }
  optionset(option* optlist) { initialise(optlist); }
  optionset(option* optlist, char *Helptext) : helptext(Helptext) { initialise(optlist); }
  void initialise(option* optlist);
  void initialise(option* optlist, char *Helptext) { initialise(optlist); helptext = Helptext; }
  bool read_options(int &argc, char ** &argv);
};

bool parse_options(option* optlist, int &argc, char ** &argv);
bool parse_options(option* optlist, char* helptext, int &argc, char ** &argv);

#endif
