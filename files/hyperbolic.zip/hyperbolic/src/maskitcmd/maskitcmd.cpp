/*
 *  maskitcmd.cpp
 *
 *  Draws the boundary of T_{1,1} in C with the Maskit embedding using
 *  Wright's algorithm
 *
 *  Command line only version
 *
 */

#include "common/common.hpp"
#include "maskit/maskitalgorithms.hpp"
#include "common/progressbar.hpp"
#include "common/optionset.hpp"
#include<iostream>
#include<strstream>
#include<utility>
#include<stdio.h>

using namespace std;
using namespace maskit;

int mc_qmax = 80;
int mc_rayqmax = 10;
bool mc_pray = true;
bool mc_nray = true;
hg_real mc_ray_max_acc = 0.1;
hg_real mc_ray_min_acc = 0.1;
hg_real mc_ray_initstep = 0.1;
newton::params mc_newton_params;
string mc_mathematica_filename;
string mc_text_filename;
string mc_postscript_filename;
string mc_zoom;
string mc_tracederivativeanalysis;
string mc_imagecircleanalysis;
int mc_ica_steps = 80;
hg_real mc_ica_eps = 1.;
bool mc_ica_nosave = false;
hg_real mc_aspectratio = 1.41421; // sqrt(2), A4 etc.

BEGINLISTOPTION(maskitcmdoptions)
LISTOPTION(int,mc_qmax,"qmax",oc_int,"Largest denominator q in fractions p/q")
LISTOPTION(int,mc_rayqmax,"rayqmax",oc_int,"Largest denominator q in fractions p/q for which a ray is calculated")
LISTOPTION(hg_real,mc_ray_max_acc,"maxacc",oc_hg_real,"Ray max accuracy")
LISTOPTION(hg_real,mc_ray_min_acc,"minacc",oc_hg_real,"Ray min accuracy")
LISTOPTION(hg_real,mc_ray_initstep,"initstep",oc_hg_real,"Ray initial stepsize")
BOOLLISTOPTION(mc_pray,"pray","Draw pleating rays")
BOOLLISTOPTION(mc_nray,"nray","Draw negative pleating rays")
LISTOPTION(string, mc_mathematica_filename, "mathematica", oc_string, "Mathematica output filename, empty means no file is written")
LISTOPTION(string, mc_text_filename, "text", oc_string, "Text output filename, empty means no file is written")
LISTOPTION(string, mc_postscript_filename, "ps", oc_string, "Postscript output filename, empty means no file is written")
LISTOPTION(string, mc_zoom, "zoom", oc_string, "output.txt:p1/q1,p2/q2 zooms to the region between fractions p1/q1 and p2/q2 from output.txt")
LISTOPTION(hg_real,mc_aspectratio,"ar",oc_hg_real,"Aspect ratio for postscript output, default is A4 landscape")
LISTOPTION(string, mc_tracederivativeanalysis,"tda",oc_string,"Trace derivative analysis filename, empty string means don't run this analysis")
LISTOPTION(string, mc_imagecircleanalysis,"ica",oc_string,"Image circle analysis filename, empty string means don't run this analysis")
LISTOPTION(hg_real,mc_ica_eps,"icaeps",oc_hg_real,"Image circle analysis epsilon")
LISTOPTION(int,mc_ica_steps,"icasteps",oc_int,"Image circle analysis steps")
BOOLLISTOPTION(mc_ica_nosave,"icanosave","Image circle analysis output summary only")
//LISTOPTION(hg_real,mc_newton_params.epsilon,"newtonepsilon",oc_hg_real,"Value of epsilon used for Newton's method algorithm")
//LISTOPTION(hg_real,mc_newton_params.parameter_accuracy,"newtonparamacc",oc_hg_real,"Value of parameter accuracy used for Newton's method algorithm")
//LISTOPTION(hg_real,mc_newton_params.value_accuracy,"newtonvalueacc",oc_hg_real,"Value of value accuracy used for Newton's method algorithm")
//LISTOPTION(int,mc_newton_params.maxiter,"newtonmaxiter",oc_int,"Maximum number of iterations used in Newton's method")
ENDLISTOPTION

text_progress_bar mg_progress;
maskit::view mview;
null_gfx_wrapper mg_gfx_wrapper;

template <class T>
bool from_string(T& t, const std::string& s)
{
  std::istringstream iss(s);
  return !(iss >> std::dec >> t).fail();
}

int main(int argc, char *argv[])
{
  mc_newton_params.epsilon = newton::def_epsilon;
  mc_newton_params.maxiter = newton::def_maxiter;
  mc_newton_params.parameter_accuracy = newton::def_parameter_accuracy;
  mc_newton_params.value_accuracy = newton::def_value_accuracy;

  optionset os(maskitcmdoptions);
  if(!os.read_options(argc,argv))
  {
	  return -1;
  }

  farey f1 = farey_0, f2=farey_1;
  hg_complex initial_mu = global_maskit_holoparams.initial_mu();

  if(int mc_zoom_len = mc_zoom.length()>0)
  {
	  string zoomfilename, fracp1, fracp2, fracq1, fracq2;
	  int pos1,pos2,pos3,pos4;
	  bool fail_parse = false;
	  int p1,q1,p2,q2;
	  bool found_f1 = false, found_f2 = false;
	  hg_complex mu1, mu2;

	  pos1 = mc_zoom.find_first_of(':');
	  if(pos1==mc_zoom_len) fail_parse = true;
	  pos2 = mc_zoom.find_first_of(',');
	  if(pos2==mc_zoom_len) fail_parse = true;
	  pos3 = mc_zoom.find_first_of('/',pos1);
	  if(pos3==mc_zoom_len) fail_parse = true;
	  pos4 = mc_zoom.find_first_of('/',pos2);
	  if(pos4==mc_zoom_len) fail_parse = true;
	  if(fail_parse || !(pos1<pos3 && pos3<pos2 && pos2<pos4))
	  {
		  cout << "Error in argument to -zoom" << endl;
		  return -1;
	  }
	  zoomfilename = mc_zoom.substr(0,pos1);
	  fracp1 = mc_zoom.substr(pos1+1,pos3-pos1-1);
	  fracq1 = mc_zoom.substr(pos3+1,pos2-pos3-1);
	  fracp2 = mc_zoom.substr(pos2+1,pos4-pos2-1);
	  fracq2 = mc_zoom.substr(pos4+1,mc_zoom_len-pos4);
	  if(!from_string(p1,fracp1)) fail_parse = true;
	  if(!from_string(p2,fracp2)) fail_parse = true;
	  if(!from_string(q1,fracq1)) fail_parse = true;
	  if(!from_string(q2,fracq2)) fail_parse = true;
	  if(fail_parse)
	  {
		  cout << "Error in argument to -zoom" << endl;
		  return -1;
	  }

	  f1 = farey(p1,q1);
	  f2 = farey(p2,q2);
	  if(f1>=f2)
	  {
		  cout << "p1/q1 must be smaller than p2/q2." << endl;
	  }

	  ifstream fin(zoomfilename.c_str());
	  if(!fin)
	  {
		  cout << "Failed to load zoom file." << endl;
		  return -1;
	  }
	  string tempstr;
	  int numpoints;
	  getline(fin,tempstr); getline(fin,tempstr); getline(fin,tempstr);
	  fin >> numpoints; getline(fin,tempstr);
	  int i=0;
	  if(p1==0&&q1==1)
	  {
		  found_f1 = true;
		  mu1 = hg_complex(0.,2.);
	  }
	  if(p2==1&&q2==1)
	  {
		  found_f2 = true;
		  mu2 = hg_complex(2.,2.);
	  }
	  while(!fin.eof() && i++<numpoints)
	  {
		  int tp,tq;
		  hg_real tx,ty;
		  fin >> tx >> ty >> tp >> tq;
		  getline(fin,tempstr);
		  if(tp==p1&&tq==q1)
		  {
			  found_f1 = true;
			  mu1 = hg_complex(tx,ty);
		  }
		  if(tp==p2&&tq==q2)
		  {
			  found_f2 = true;
			  mu2 = hg_complex(tx,ty);
		  }
	  }
	  fin.close();

	  if(!found_f1 || !found_f2)
	  {
		  cout << "Could not find those fractions in that datafile." << endl;
		  return -1;
	  }

	  initial_mu = mu1;
  }

  mg_progress.set_numjumps(10);
  mg_progress.set_ostream(cout);

  mview.set_progress_bar(&mg_progress);
  mview.set_preview(&mg_gfx_wrapper);

  mview.set_maxdenom(mc_qmax);
  mview.set_maxdenomray(mc_rayqmax);
  mview.show_prays(mc_pray);
  mview.show_nrays(mc_nray);
  mview.set_boundary_level((hg_real)0.);
  mview.set_ray_params(mc_ray_max_acc,mc_ray_min_acc,mc_ray_initstep);
  mview.set_newton_params(mc_newton_params);
  mview.get_params().viewport.set(hg_complex(0.,1.),hg_complex(2.,3.));
  mview.compute_boundary(f1,f2,initial_mu);
  if(mc_pray) mview.compute_prays();
  if(mc_nray) mview.compute_nrays();
  mview.zoom_to_boundary(mc_aspectratio);
  if(mc_mathematica_filename.length()>0) 
  {
	  cout << "Writing Mathematica output to file " << mc_mathematica_filename << endl;
	  mview.create_mathematica(mc_mathematica_filename.c_str());
  }
  if(mc_text_filename.length()>0) 
  {
	  cout << "Writing text output to file " << mc_text_filename << endl;
	  mview.create_ascii(mc_text_filename.c_str());
  }
  if(mc_postscript_filename.length()>0) 
  {
	  cout << "Writing postscript output to file " << mc_postscript_filename << endl;
	  mview.create_postscript(mc_postscript_filename.c_str());
  }
  if(mc_tracederivativeanalysis.length()>0)
  {
	  cout << "Running trace derivative analysis and saving to file " << mc_tracederivativeanalysis << endl;
	  mview.tracederivative_analysis(mc_tracederivativeanalysis.c_str());
  }
  if(mc_imagecircleanalysis.length()>0 || mc_ica_nosave)
  {
	  if(mc_imagecircleanalysis.length()>0) cout << "Running image circle analysis and saving to file " << mc_imagecircleanalysis << endl;
	  else cout << "Running image circle analysis without saving." << endl;
	  pair<hg_real,hg_real> p = mview.imagecircleanalysis(mc_ica_eps,mc_ica_steps,mc_imagecircleanalysis.c_str());
	  cout << "Results: Min = " << p.first << ", Max = " << p.second << endl;
  }

  return 0;
}
