Maskit slice computation C++ routines
Dan Goodman 2005
=====================================

I have tested these with MS Visual C++ 6.0 and on various versions of gcc on linux.

Installing and compiling on MS Visual C++
-----------------------------------------

Simply open the src/maskitcmd/maskitcmd.dsw project workspace and it should compile and run. You will need to add the src directory to the Visual C++ includes path.

Installing and compiling on Linux or Unix
-----------------------------------------

From the src/ directory, type make and the project should compile to bin/maskitcmd.
There may be some warnings on compilation, but it should still work.

Usage
-----

Type bin/maskitcmd -h to get a list of options. For example, to draw the Maskit slice
based on all cusps p/q between 0 and 1 with q<=160 and to write this to the Mathematica
notebook output/maskit.nb you would type

bin/maskitcmd -qmax 160 -notpray -notnray -mathematica output/maskit.nb

Questions? Problems? Email Dan Goodman dan@thesamovar.net